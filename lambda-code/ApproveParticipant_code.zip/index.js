// Approve participant - updates DynamoDB and creates Leader + Team in RDS

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import mysql from 'mysql2/promise';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: "ap-southeast-1" });
const docClient = DynamoDBDocumentClient.from(client);

const TABLE_NAME = process.env.TABLE_NAME || 'HackathonRegistrations';

// RDS connection configuration
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'hackhub',
    port: parseInt(process.env.DB_PORT || '3306'),
};

// Map DynamoDB track names to RDS track titles
const TRACK_MAPPING = {
    'student': 'Student',
    'corporate': 'Corporate',
    'open': 'Corporate' // fallback to Corporate
};

export const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event));

    const responseHeaders = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
    };

    if (event.httpMethod === "OPTIONS") {
        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify({ message: "CORS preflight passed" }),
        };
    }

    let connection;

    try {
        const participantId = event.pathParameters?.id;

        if (!participantId) {
            return {
                statusCode: 400,
                headers: responseHeaders,
                body: JSON.stringify({ message: 'Participant ID is required.' }),
            };
        }

        // 1. Get participant data from DynamoDB
        console.log('Fetching participant from DynamoDB:', participantId);
        const getParams = {
            TableName: TABLE_NAME,
            Key: {
                participant_id: participantId,
            },
        };

        const getResult = await docClient.send(new GetCommand(getParams));
        
        if (!getResult.Item) {
            return {
                statusCode: 404,
                headers: responseHeaders,
                body: JSON.stringify({ message: 'Participant not found.' }),
            };
        }

        const participant = getResult.Item;
        console.log('Participant data:', JSON.stringify(participant));

        // Parse leader info
        const leaderInfo = typeof participant.leader === 'string' 
            ? JSON.parse(participant.leader) 
            : participant.leader;
        
        const leaderEmail = leaderInfo.email;
        const teamName = participant.teamName;
        const trackName = participant.track;

        // 2. Connect to RDS
        console.log('Connecting to RDS...');
        connection = await mysql.createConnection(dbConfig);

        // 3. Get track_id from RDS
        const trackTitle = TRACK_MAPPING[trackName] || 'Data Analytics';
        console.log('Looking up track:', trackTitle);
        
        const [trackRows] = await connection.execute(
            'SELECT track_id FROM Track WHERE track_title = ? LIMIT 1',
            [trackTitle]
        );

        if (trackRows.length === 0) {
            throw new Error(`Track not found: ${trackTitle}`);
        }

        const trackId = trackRows[0].track_id;
        console.log('Found track_id:', trackId);

        // 4. Check if leader already exists
        const [existingLeaders] = await connection.execute(
            'SELECT leader_id FROM Leader WHERE email_address = ?',
            [leaderEmail]
        );

        let leaderId;
        
        if (existingLeaders.length > 0) {
            leaderId = existingLeaders[0].leader_id;
            console.log('Leader already exists:', leaderId);
        } else {
            // Create new leader
            leaderId = uuidv4();
            console.log('Creating new leader:', leaderId);
            
            await connection.execute(
                'INSERT INTO Leader (leader_id, email_address, track_id) VALUES (?, ?, ?)',
                [leaderId, leaderEmail, trackId]
            );
            console.log('Leader created successfully');
        }

        // 5. Check if team already exists for this leader
        const [existingTeams] = await connection.execute(
            'SELECT team_id FROM Team WHERE leader_id = ?',
            [leaderId]
        );

        let teamId;

        if (existingTeams.length > 0) {
            teamId = existingTeams[0].team_id;
            console.log('Team already exists:', teamId);
            
            // Update team name if different
            await connection.execute(
                'UPDATE Team SET team_name = ? WHERE team_id = ?',
                [teamName, teamId]
            );
        } else {
            // Create new team
            teamId = uuidv4();
            console.log('Creating new team:', teamId);
            
            await connection.execute(
                'INSERT INTO Team (team_id, leader_id, team_name) VALUES (?, ?, ?)',
                [teamId, leaderId, teamName]
            );
            console.log('Team created successfully');
        }

        // 6. Update DynamoDB status to APPROVED
        const updateParams = {
            TableName: TABLE_NAME,
            Key: {
                participant_id: participantId,
            },
            UpdateExpression: 'SET #status = :approved',
            ExpressionAttributeNames: {
                '#status': 'status',
            },
            ExpressionAttributeValues: {
                ':approved': 'APPROVED',
            },
            ReturnValues: 'ALL_NEW',
        };

        console.log('Updating DynamoDB status to APPROVED');
        const updateResult = await docClient.send(new UpdateCommand(updateParams));
        console.log('Participant approved successfully');

        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify({
                message: 'Participant approved successfully',
                participant: updateResult.Attributes,
                rds: {
                    leader_id: leaderId,
                    team_id: teamId,
                    track_id: trackId
                }
            }),
        };

    } catch (error) {
        console.error('Error approving participant:', error);
        return {
            statusCode: 500,
            headers: responseHeaders,
            body: JSON.stringify({
                message: 'Failed to approve participant',
                error: error.message,
                stack: error.stack
            }),
        };
    } finally {
        if (connection) {
            await connection.end();
            console.log('Database connection closed');
        }
    }
};
