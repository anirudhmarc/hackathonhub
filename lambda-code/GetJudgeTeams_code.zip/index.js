// FIXED GetJudgeTeams Lambda - Returns ALL teams, not just those with submissions
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const s3 = new AWS.S3({ region: process.env.REGION || 'ap-southeast-2' });

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);
const S3_BUCKET_NAME = process.env.S3_BUCKET_NAME;

let connectionPool = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing.");
    }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) {
        return JSON.parse(data.SecretString);
    }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (!connectionPool) {
        const creds = await getDbCredentials();
        connectionPool = mysql.createPool({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Database connection pool created.');
    }
    return connectionPool.getConnection();
}

// Convert an S3 URL or key to a presigned GET URL
async function getPresignedUrl(s3UrlOrKey) {
    if (!s3UrlOrKey || !S3_BUCKET_NAME) return s3UrlOrKey;

    let s3Key = s3UrlOrKey;
    if (s3UrlOrKey.startsWith('https://')) {
        try {
            const url = new URL(s3UrlOrKey);
            // Decode percent-encoding from the URL path so the S3 key matches the real
            // object key (e.g. "Observability (1).pptx", not "Observability%20(1).pptx").
            // The SDK re-encodes the key when signing, so a pre-encoded key causes 404s.
            const rawPath = url.pathname.startsWith('/') ? url.pathname.slice(1) : url.pathname;
            s3Key = decodeURIComponent(rawPath);
        } catch (e) {
            console.warn('Failed to parse URL, using as key:', s3UrlOrKey);
        }
    }

    try {
        return await s3.getSignedUrlPromise('getObject', {
            Bucket: S3_BUCKET_NAME,
            Key: s3Key,
            Expires: 604800, // 7 days (maximum)
        });
    } catch (error) {
        console.error('Failed to generate presigned URL for:', s3Key, error.message);
        return s3UrlOrKey;
    }
}

// Additional materials are stored as a JSON-array string (or a single URL/key, or an
// already-parsed array). Presign EACH element individually and return a JSON-array
// string, matching the shape the judge frontend expects (it JSON.parses this value).
async function presignAdditionalMaterials(raw) {
    if (!raw) return raw;
    let urls = [];
    if (Array.isArray(raw)) {
        urls = raw;
    } else if (typeof raw === 'string') {
        try {
            const parsed = JSON.parse(raw);
            urls = Array.isArray(parsed) ? parsed : [parsed];
        } catch (e) {
            urls = [raw];
        }
    }
    const presigned = await Promise.all(urls.filter(Boolean).map(url => getPresignedUrl(url)));
    return JSON.stringify(presigned);
}

exports.handler = async (event) => {
    let connection;
    try {
        const stageId = event.queryStringParameters?.stage_id;
        
        connection = await connectToDatabase();
        
        // FIXED: Changed to LEFT JOIN so teams without submissions are included
        let sqlQuery = `
            SELECT
                t.team_id AS id,
                t.team_name AS name,
                t.is_finalist,
                ps.problem_id,
                ps.problem_title AS problem_statement,
                track.track_title AS track,
                ts.submission_video_url,
                ts.submission_project_description,
                ts.github_url,
                ts.submission_additional_materials_url,
                ts.last_updated,
                ts.submission_id
            FROM Team t
            LEFT JOIN Team_Submission ts ON t.team_id = ts.team_id
            LEFT JOIN Leader l ON t.leader_id = l.leader_id
            LEFT JOIN Track track ON l.track_id = track.track_id
            LEFT JOIN Problem_Statement ps ON t.problem_id = ps.problem_id
            WHERE 1=1
        `;
        
        const queryParams = [];

        // For the second stage, only show finalist teams
        if (stageId && stageId.includes('stage-2')) {
            sqlQuery += ` AND t.is_finalist = ?`;
            queryParams.push(1);
        }

        sqlQuery += ` ORDER BY t.team_name ASC`;

        const [teams] = await connection.execute(sqlQuery, queryParams);
        
        console.log('✅ FIXED LAMBDA - Total teams returned:', teams.length);
        console.log('✅ Teams with submissions:', teams.filter(t => t.submission_video_url).length);
        console.log('✅ Teams without submissions:', teams.filter(t => !t.submission_video_url).length);
        
        // Format the response with presigned URLs for S3 resources
        const formattedTeams = await Promise.all(teams.map(async (team) => ({
            id: team.id,
            name: team.name,
            is_finalist: team.is_finalist === 1,
            problem_id: team.problem_id,
            problem_statement: team.problem_statement,
            track: team.track || 'unknown',
            submission_video_url: await getPresignedUrl(team.submission_video_url),
            submission_project_description: team.submission_project_description || null,
            github_url: team.github_url || null,
            submission_additional_materials_url: await presignAdditionalMaterials(team.submission_additional_materials_url),
            last_updated: team.last_updated ? team.last_updated.toISOString() : null
        })));

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify(formattedTeams)
        };
    } catch (error) {
        console.error('Error fetching teams:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: 'Failed to fetch teams', details: error.message })
        };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};
