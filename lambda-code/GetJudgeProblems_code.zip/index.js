const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let connectionPool = null;

async function getDbCredentials() {
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    return JSON.parse(data.SecretString);
}

async function connectToDatabase() {
    // Jika pool belum dibuat, buat yang baru
    if (!connectionPool) {
        const creds = await getDbCredentials();
        connectionPool = mysql.createPool({ // Gunakan createPool di sini
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Database connection pool created.');
    }
    return connectionPool.getConnection(); // Dapatkan koneksi dari pool
}

exports.handler = async (event) => {
    let connection;
    try {
        connection = await connectToDatabase();
        const [problemStatements] = await connection.execute(`
            SELECT
                problem_id AS id,
                problem_title AS name,
                problem_description,
                problem_tag,
                problem_max_slots,
                track_id
            FROM Problem_Statement
        `);
        return {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify(problemStatements),
        };
    } catch (error) {
        console.error("Database query failed:", error);
        return {
            statusCode: 500,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({ message: "Internal Server Error", error: error.message }),
        };
    }
};