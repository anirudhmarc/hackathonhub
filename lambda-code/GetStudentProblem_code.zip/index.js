// GetProblemTeam/index.js - NEW LAMBDA for GET /participant/problem
const mysql = require("mysql2/promise");
const AWS = require("aws-sdk");
const secretsManager = new AWS.SecretsManager();

// Environment variables
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || "3306", 10);

let cachedConnection = null;

async function getDbCredentials() {
  if (!DB_SECRET_ARN) {
    throw new Error("Database secret ARN is missing.");
  }
  const data = await secretsManager
    .getSecretValue({ SecretId: DB_SECRET_ARN })
    .promise();
  if ("SecretString" in data) {
    return JSON.parse(data.SecretString);
  }
  throw new Error("SecretString not found in Secrets Manager response.");
}

async function connectToDatabase() {
  if (
    cachedConnection &&
    cachedConnection.isValid &&
    cachedConnection.isValid()
  ) {
    console.log("Using cached database connection.");
    return cachedConnection;
  }
  const creds = await getDbCredentials();
  const connection = await mysql.createConnection({
    host: DB_HOST,
    user: creds.username,
    password: creds.password,
    database: DB_DATABASE,
    port: DB_PORT,
  });
  cachedConnection = connection;
  return connection;
}

exports.handler = async (event) => {
  let connection;
  try {
    const token = event.headers.Authorization?.split(" ")[1]; // Expect token for authorization
    if (!token) {
      return {
        statusCode: 401,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ message: "Authorization token missing." }),
      };
    }

    const userEmail = event.requestContext.authorizer.claims.email; // Get user email from Cognito Authorizer
    const userGroups =
      event.requestContext.authorizer.claims["cognito:groups"] || [];
    const isParticipant = userGroups.includes("Participants");

    if (!isParticipant) {
      return {
        statusCode: 403,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: "Forbidden. User is not a participant.",
        }),
      };
    }

    connection = await connectToDatabase();

    // 1. Get the user's team's track_id
    const [leaderRows] = await connection.execute(
      "SELECT leader_id, track_id FROM Leader WHERE email_address = ?",
      [userEmail]
    );
    if (leaderRows.length === 0) {
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: "Leader not found. Please register a team first.",
        }),
      };
    }
    const userTrackId = leaderRows[0].track_id;
    const leaderId = leaderRows[0].leader_id; // Also get leaderId to find teamId later

    // 2. Get the user's team's problem_id (if already selected)
    const [teamRows] = await connection.execute(
      "SELECT team_id, problem_id FROM Team WHERE leader_id = ?",
      [leaderId]
    );
    let userSelectedProblemId = null;
    if (teamRows.length > 0) {
      userSelectedProblemId = teamRows[0].problem_id;
    }

    // 3. Fetch all problem statements, filter by user's track_id, and get slot counts
    const [rows] = await connection.execute(
      `
            SELECT
                ps.problem_id,
                ps.problem_title,
                ps.problem_description,
                ps.problem_tag,
                ps.problem_max_slots,
                COALESCE(COUNT(t.team_id), 0) AS current_slots_taken,
                tr.track_title AS track_name
            FROM
                Problem_Statement ps
            LEFT JOIN
                Team t ON ps.problem_id = t.problem_id
            JOIN
                Track tr ON ps.track_id = tr.track_id
            WHERE
                ps.track_id = ? -- Filter by user's track_id
            GROUP BY
                ps.problem_id, ps.problem_title, ps.problem_description, ps.problem_tag, ps.problem_max_slots, tr.track_title
            ORDER BY ps.problem_title ASC;
        `,
      [userTrackId]
    ); // Pass userTrackId as parameter

    // Map the rows to match the ProblemStatement interface for the frontend
    const problemStatements = rows.map((row) => ({
      problem_id: row.problem_id,
      problem_title: row.problem_title,
      problem_description: row.problem_description,
      problem_tag: row.problem_tag,
      problem_max_slots: row.problem_max_slots,
      current_slots_taken: row.current_slots_taken,
      track_name: row.track_name,
      selected: row.problem_id === userSelectedProblemId, // Mark as selected if it's the user's current choice
      remainingSlots: row.problem_max_slots - row.current_slots_taken, // Calculate remaining slots
    }));

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*", // Adjust CORS as needed
      },
      body: JSON.stringify(problemStatements), // Return the array directly
    };
  } catch (error) {
    console.error(
      "Error fetching problem statements in GetProblemTeam:",
      error
    );
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        message: "Failed to retrieve problem statements",
        error: error.message,
      }),
    };
  } finally {
    // Connection handling
    if (connection) {
      connection.end();
    }
  }
};
