// Approve participant - updates DynamoDB, creates Leader + Team in RDS,
// invokes CognitoUserManager (non-VPC) for Cognito account creation

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";
import { LambdaClient, InvokeCommand } from "@aws-sdk/client-lambda";
import mysql from 'mysql2/promise';
import { v4 as uuidv4 } from 'uuid';

const REGION = process.env.REGION || "ap-southeast-2";
const ddbClient = new DynamoDBClient({ region: REGION });
const docClient = DynamoDBDocumentClient.from(ddbClient);
const lambdaClient = new LambdaClient({ region: REGION });
const secretsClient = new SecretsManagerClient({ region: REGION });

const TABLE_NAME = process.env.DYNAMODB_TABLE_NAME || process.env.TABLE_NAME || 'HackathonRegistrations';
const COGNITO_USER_POOL_ID = process.env.COGNITO_USER_POOL_ID;
const COGNITO_MANAGER_FUNCTION = process.env.COGNITO_MANAGER_FUNCTION || 'hackhub-test-13-prod-CognitoUserManager';
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE || process.env.DB_NAME || 'hackhub';
const DB_PORT = parseInt(process.env.DB_PORT || '3306');

async function getDbCredentials() {
    const data = await secretsClient.send(new GetSecretValueCommand({ SecretId: DB_SECRET_ARN }));
    return JSON.parse(data.SecretString);
}

// Map DynamoDB track names to RDS track titles
const TRACK_MAPPING = {
    'student': 'Student Track',
    'corporate': 'Corporate Track',
    'open': 'Corporate Track'
};

async function invokeCognitoManager(email, name, groupName) {
    const payload = {
        userPoolId: COGNITO_USER_POOL_ID,
        username: email,
        name: name,
        groupName: groupName,
    };

    try {
        const response = await lambdaClient.send(new InvokeCommand({
            FunctionName: COGNITO_MANAGER_FUNCTION,
            InvocationType: 'RequestResponse',
            Payload: JSON.stringify(payload),
        }));

        const result = JSON.parse(new TextDecoder().decode(response.Payload));
        console.log(`CognitoUserManager result for ${email}:`, JSON.stringify(result));
        return { email, ...result };
    } catch (error) {
        console.error(`CognitoUserManager invocation failed for ${email}:`, error.message);
        return { email, error: error.message };
    }
}

export const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event));

    const responseHeaders = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
    };

    if (event.httpMethod === "OPTIONS") {
        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify({ message: "CORS preflight passed" }),
        };
    }

    let connection;

    try {
        const participantId = event.pathParameters?.id;

        if (!participantId) {
            return {
                statusCode: 400,
                headers: responseHeaders,
                body: JSON.stringify({ message: 'Participant ID is required.' }),
            };
        }

        // 1. Get participant data from DynamoDB
        console.log('Fetching participant from DynamoDB:', participantId);
        const getResult = await docClient.send(new GetCommand({
            TableName: TABLE_NAME,
            Key: { participant_id: participantId },
        }));

        if (!getResult.Item) {
            return {
                statusCode: 404,
                headers: responseHeaders,
                body: JSON.stringify({ message: 'Participant not found.' }),
            };
        }

        const participant = getResult.Item;
        console.log('Participant data:', JSON.stringify(participant));

        // Parse leader info
        const leaderInfo = typeof participant.leader === 'string'
            ? JSON.parse(participant.leader)
            : participant.leader;

        // Parse members info
        const membersInfo = typeof participant.members === 'string'
            ? JSON.parse(participant.members)
            : (participant.members || []);

        const leaderEmail = leaderInfo.email;
        const teamName = participant.teamName;
        const trackName = participant.track;

        // Collect all emails from DynamoDB record
        const allEmails = Array.isArray(participant.emails) ? participant.emails : [];

        // 2. Connect to RDS using credentials from Secrets Manager
        console.log('Connecting to RDS...');
        const creds = await getDbCredentials();
        connection = await mysql.createConnection({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT,
        });

        // 3. Get track_id from RDS
        const trackTitle = TRACK_MAPPING[trackName?.toLowerCase()] || 'Student Track';
        console.log('Looking up track:', trackTitle);

        const [trackRows] = await connection.execute(
            'SELECT track_id FROM Track WHERE track_title = ? LIMIT 1',
            [trackTitle]
        );

        if (trackRows.length === 0) {
            throw new Error(`Track not found: ${trackTitle}`);
        }

        const trackId = trackRows[0].track_id;

        // 4. Check if leader already exists
        const [existingLeaders] = await connection.execute(
            'SELECT leader_id FROM Leader WHERE email_address = ?',
            [leaderEmail]
        );

        let leaderId;

        if (existingLeaders.length > 0) {
            leaderId = existingLeaders[0].leader_id;
            console.log('Leader already exists:', leaderId);
        } else {
            leaderId = uuidv4();
            await connection.execute(
                'INSERT INTO Leader (leader_id, email_address, track_id) VALUES (?, ?, ?)',
                [leaderId, leaderEmail, trackId]
            );
            console.log('Leader created:', leaderId);
        }

        // 5. Check if team already exists
        const [existingTeams] = await connection.execute(
            'SELECT team_id FROM Team WHERE leader_id = ?',
            [leaderId]
        );

        let teamId;

        if (existingTeams.length > 0) {
            teamId = existingTeams[0].team_id;
            await connection.execute(
                'UPDATE Team SET team_name = ? WHERE team_id = ?',
                [teamName, teamId]
            );
        } else {
            teamId = uuidv4();
            await connection.execute(
                'INSERT INTO Team (team_id, leader_id, team_name) VALUES (?, ?, ?)',
                [teamId, leaderId, teamName]
            );
            console.log('Team created:', teamId);
        }

        // 6. Create Cognito accounts via CognitoUserManager (non-VPC Lambda)
        console.log('Creating Cognito accounts for team members...');

        // Build email -> name map
        const emailNameMap = new Map();
        emailNameMap.set(leaderEmail.toLowerCase(), leaderInfo.name || leaderEmail);

        const nonLeaderEmails = allEmails.filter(e => e.toLowerCase() !== leaderEmail.toLowerCase());
        const memberNames = Array.isArray(membersInfo) ? membersInfo : [];

        for (let i = 0; i < nonLeaderEmails.length; i++) {
            const email = nonLeaderEmails[i];
            const memberName = memberNames[i]?.name || email;
            emailNameMap.set(email.toLowerCase(), memberName);
        }

        const cognitoResults = [];
        for (const [email, name] of emailNameMap) {
            const result = await invokeCognitoManager(email, name, 'Participants');
            cognitoResults.push(result);
        }

        console.log('Cognito results:', JSON.stringify(cognitoResults));

        // 7. Update DynamoDB status to APPROVED
        const updateResult = await docClient.send(new UpdateCommand({
            TableName: TABLE_NAME,
            Key: { participant_id: participantId },
            UpdateExpression: 'SET #status = :approved',
            ExpressionAttributeNames: { '#status': 'status' },
            ExpressionAttributeValues: { ':approved': 'APPROVED' },
            ReturnValues: 'ALL_NEW',
        }));

        console.log('Participant approved successfully');

        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify({
                message: 'Participant approved successfully',
                participant: updateResult.Attributes,
                rds: { leader_id: leaderId, team_id: teamId, track_id: trackId },
                cognito: cognitoResults,
            }),
        };

    } catch (error) {
        console.error('Error approving participant:', error);
        return {
            statusCode: 500,
            headers: responseHeaders,
            body: JSON.stringify({
                message: 'Failed to approve participant',
                error: error.message,
                stack: error.stack
            }),
        };
    } finally {
        if (connection) {
            await connection.end();
            console.log('Database connection closed');
        }
    }
};
