// GetStudentSubmission/index.js - NEW LAMBDA for GET /participant/submission
import mysql from 'mysql2/promise'; // Changed this line
import AWS from 'aws-sdk'; // Changed this line
const secretsManager = new AWS.SecretsManager();

// Environment variables
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        console.log('Using cached database connection.');
        return cachedConnection;
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

export const handler = async (event) => { // Changed this line
    let connection;
    try {
        const token = event.headers.Authorization?.split(' ')[1];
        if (!token) {
            return {
                statusCode: 401,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Authorization token missing.' }),
            };
        }

        const userEmail = event.requestContext.authorizer.claims.email;
        const userGroups = event.requestContext.authorizer.claims['cognito:groups'] || [];
        const isParticipant = userGroups.includes('Participants');
        
        if (!isParticipant) {
             return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Forbidden. User is not a participant.' }),
            };
        }

        connection = await connectToDatabase();

        // 1. Find the leader_id for the user
        const [leaderRows] = await connection.execute('SELECT leader_id FROM Leader WHERE email_address = ?', [userEmail]);
        if (leaderRows.length === 0) {
            return {
                statusCode: 200, // OK, but no submission found for this user/leader
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ submission: null, message: 'Leader not found, no submission possible.' }),
            };
        }
        const leaderId = leaderRows[0].leader_id;

        // 2. Find the team_id for this leader
        const [teamRows] = await connection.execute('SELECT team_id, problem_id FROM Team WHERE leader_id = ?', [leaderId]);
        if (teamRows.length === 0) {
            return {
                statusCode: 200, // OK, but no submission found for this team
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ submission: null, message: 'Team not found for this leader.' }),
            };
        }
        const teamId = teamRows[0].team_id;
        const problemId = teamRows[0].problem_id; // Get problemId from team table

        // 3. Get the latest submission for this team
        const [submissionRows] = await connection.execute(
            `SELECT
                submission_id,
                team_id,
                last_updated,
                submission_video_url,
                github_url,
                submission_project_description,
                submission_additional_materials_url
            FROM Team_Submission
            WHERE team_id = ?
            ORDER BY last_updated DESC
            LIMIT 1`,
            [teamId]
        );

        let submission = null;
        if (submissionRows.length > 0) {
            submission = submissionRows[0];
            // If submission_additional_materials_url is stored as a JSON string, parse it
            if (submission.submission_additional_materials_url && typeof submission.submission_additional_materials_url === 'string') {
                try {
                    submission.submission_additional_materials_url = JSON.parse(submission.submission_additional_materials_url);
                } catch (e) {
                    console.error('Failed to parse submission_additional_materials_url:', e);
                    submission.submission_additional_materials_url = []; // Default to empty array on parse error
                }
            } else if (!submission.submission_additional_materials_url) {
                 submission.submission_additional_materials_url = []; // Ensure it's an array if null/undefined
            }
        }

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ submission: submission, teamId: teamId, problemId: problemId }), // Include teamId and problemId
        };
    } catch (error) {
        console.error('Error in GetStudentSubmission handler:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ message: 'Failed to retrieve submission', error: error.message }),
        };
    } finally {
        if (connection) {
            try {
                await connection.end();
                console.log('Database connection closed.');
            } catch (err) {
                console.error('Failed to close database connection:', err);
            }
        }
    }
};