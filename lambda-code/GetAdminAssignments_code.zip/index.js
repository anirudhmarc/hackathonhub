// get-admin-assignments/index.js
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const { v4: uuidv4 } = require('uuid');

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    console.log('Fetching DB credentials from Secrets Manager...');
    try {
        const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
        if ('SecretString' in data) {
            console.log('Successfully fetched secret from Secrets Manager.');
            return JSON.parse(data.SecretString);
        }
        throw new Error('SecretString not found in Secrets Manager response.');
    } catch (err) {
        console.error('Error retrieving secret from Secrets Manager:', err);
        throw err;
    }
}

async function connectToDatabase() {
    console.log('Checking for cached database connection...');
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        console.log('Using cached database connection.');
        return cachedConnection;
    }

    const creds = await getDbCredentials();
    console.log("Connecting to database with host:", DB_HOST, "user:", creds.username, "database:", DB_DATABASE, "port:", DB_PORT);

    try {
        const connection = await mysql.createConnection({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Successfully established new database connection.');
        cachedConnection = connection;
        return connection;
    } catch (err) {
        console.error('Error establishing database connection:', err);
        throw err;
    }
}

exports.handler = async (event) => {
    let connection;
    try {
        connection = await connectToDatabase();

        const [rows] = await connection.execute(`
            SELECT
                ja.assignment_id AS id,
                ja.judge_id,
                j.judge_name,
                j.email_address AS judge_email,
                ja.team_id,
                t.team_name,
                ja.assigned_at,
                ja.stage_id,
                js.stage_name
            FROM
                Judge_Assignment ja
            JOIN
                Judge j ON ja.judge_id = j.judge_id
            JOIN
                Team t ON ja.team_id = t.team_id
            JOIN
                Judging_Stage js ON ja.stage_id = js.stage_id
            ORDER BY j.judge_name, t.team_name ASC
        `);

        const assignmentsData = rows.map(row => ({
            id: row.id,
            judgeId: row.judge_id,
            judgeName: row.judge_name,
            judgeEmail: row.judge_email,
            teamId: row.team_id,
            teamName: row.team_name,
            assignedAt: row.assigned_at,
            stageId: row.stage_id,
            stageName: row.stage_name,
        }));

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify(assignmentsData),
        };
    } catch (error) {
        console.error('Error fetching assignments:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to fetch assignments', error: error.message }),
        };
    }
};
