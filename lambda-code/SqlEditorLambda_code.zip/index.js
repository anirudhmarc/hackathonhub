// SqlEditorLambda/index.js
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

// Environment variables for database connection details
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null; // Cache connection for re-use

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        console.error("DB_SECRET_ARN environment variable is not set. Cannot fetch credentials.");
        throw new Error("Database secret ARN is missing.");
    }
    try {
        const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
        if ('SecretString' in data) {
            return JSON.parse(data.SecretString);
        }
        throw new Error('SecretString not found in Secrets Manager response.');
    } catch (err) {
        console.error('Error retrieving secret from Secrets Manager:', err);
        throw err;
    }
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        return cachedConnection;
    }

    const creds = await getDbCredentials();

    try {
        const connection = await mysql.createConnection({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE, // Connect directly to the database
            port: DB_PORT
        });
        cachedConnection = connection;
        return connection;
    } catch (err) {
        console.error('Error establishing database connection:', err);
        throw err;
    }
}

exports.handler = async (event) => {
    let connection;
    try {
        console.log('Received event:', JSON.stringify(event));

        const sqlQuery = event.sql; // The SQL query will come from the 'sql' property in the test event
        if (!sqlQuery) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'Missing "sql" property in event payload.' }),
            };
        }

        console.log(`Attempting to connect to database '${DB_DATABASE}' and execute SQL query...`);
        connection = await connectToDatabase();
        console.log('Database connection obtained (new or cached).');

        console.log(`Executing SQL: ${sqlQuery.substring(0, 200)}...`); // Log first 200 chars of query
        const [rows, fields] = await connection.query(sqlQuery); // Use .query() for flexibility with DDL/DML

        console.log('SQL query executed successfully.');

        return {
            statusCode: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' // For potential future API Gateway integration
            },
            body: JSON.stringify({ results: rows, fields: fields }), // Return rows and fields
        };
    } catch (error) {
        console.error('Error executing SQL query:', error);
        return {
            statusCode: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' 
            },
            body: JSON.stringify({ message: 'Failed to execute SQL query', error: error.message, sql: event.sql }),
        };
    } finally {
        // Do NOT close cachedConnection here if you want to reuse it.
        // For this specific SQL editor, you might want to close it if it's a one-off tool.
        // If connection is not cached: if (connection) await connection.end();
    }
};