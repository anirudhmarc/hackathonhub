// cognito-user-manager/index.js
// This Lambda function is designed to be deployed OUTSIDE of a VPC
// to allow it to directly access AWS Cognito's public endpoints and SES.

import { CognitoIdentityProviderClient, AdminCreateUserCommand, AdminAddUserToGroupCommand } from "@aws-sdk/client-cognito-identity-provider";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses"; // Import SES Client and Command

// Configure AWS SDK Clients
const cognitoClient = new CognitoIdentityProviderClient({ region: "ap-southeast-1" }); // Your Cognito User Pool region
const sesClient = new SESClient({ region: "ap-southeast-1" }); // Your SES region (MUST be ap-southeast-1 where your sender email is verified)

// --- Email Content Generation Function ---
const generateApprovalEmailContent = (recipientName, username, temporaryPassword, hackhubLoginLink) => {
    // HTML template for the approval email
    const htmlTemplate = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Hackathon Registration Approved! Your Login Details</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; }
        .container { background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 30px; }
        .header { text-align: center; border-bottom: 2px solid #232F3E; padding-bottom: 20px; margin-bottom: 20px; }
        .header h1 { color: #232F3E; margin: 0; font-size: 24px; }
        .success-message { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center; font-weight: bold; }
        .details-box { background: #e9ecef; padding: 20px; border-left: 4px solid #007bff; margin: 20px 0; border-radius: 5px; }
        .details-box p { margin: 5px 0; }
        .call-to-action { text-align: center; margin: 30px 0; }
        .call-to-action a { background-color: #232F3E; color: #ffffff; padding: 12px 25px; border-radius: 5px; text-decoration: none; font-weight: bold; }
        .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; border-top: 1px solid #eee; padding-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 Great AI Hackathon 2025</h1>
            <p>Registration Approved!</p>
        </div>

        <div class="success-message">
            <h2>🎉 Your Registration Has Been Approved!</h2>
        </div>

        <p>Dear <strong>${recipientName}</strong>,</p>
        
        <p>We are excited to inform you that your registration for the Great AI Hackathon 2025 has been officially approved by the organization team!</p>

        <div class="details-box">
            <h3>🔑 Your Hackhub Login Details:</h3>
            <p><strong>Email (Username):</strong> <code>${username}</code></p>
            <p><strong>Temporary Password:</strong> <code>${temporaryPassword}</code></p>
            <p style="font-size: 14px; color: #dc3545;"><strong>Important:</strong> For security, please change your password immediately after your first login.</p>
        </div>

        <div class="call-to-action">
            <p>Click the button below to log in to the Hackhub platform:</p>
            <a href="${hackhubLoginLink}">Login to Hackhub</a>
        </div>

        <p>We look forward to seeing your innovative ideas!</p>
        <p>If you have any questions, feel free to contact us at <a href="mailto:admin@greataihackathon.com">admin@greataihackathon.com</a>.</p>

        <div class="footer">
            <p>
                This is an automated email for the Great AI Hackathon 2025.<br>
                © 2025 APU AWS Cloud Club. All rights reserved.
            </p>
        </div>
    </div>
</body>
</html>`;

    // Plain text fallback for the approval email
    const textTemplate = `
Great AI Hackathon 2025 - Registration Approved!

Dear ${recipientName},

We are excited to inform you that your registration for the Great AI Hackathon 2025 has been officially approved by the organization team!

Your Hackhub Login Details:
Email (Username): ${username}
Temporary Password: ${temporaryPassword}

Important: For security, please change your password immediately after your first login.

Login to Hackhub here: ${hackhubLoginLink}

We look forward to seeing your innovative ideas!
If you have any questions, feel free to contact us at admin@greataihackathon.com.

Regards,
The Hackathon Organization Team
APU AWS Cloud Club
`;

    return { htmlTemplate, textTemplate };
};
// --- End Email Content Generation Function ---


export const handler = async (event) => {
    console.log('Received event for Cognito user management:', JSON.stringify(event));

    const { userPoolId, username, name, groupName } = event; 

    if (!userPoolId || !username || !name || !groupName) {
        console.error("Missing required parameters for Cognito operation:", { userPoolId, username, name, groupName });
        throw new Error("Missing required parameters for Cognito operation. Please provide userPoolId, username, name, and groupName.");
    }

    const DEFAULT_PASSWORD = 'greataihackathon2025@APU'; 
    const HACKHUB_LOGIN_LINK = 'https://hackhub.greataihackathon.com';

    try {
        console.log(`Attempting to create/verify Cognito user for email: ${username}`);
        
        const adminCreateUserParams = {
            UserPoolId: userPoolId,
            Username: username,
            TemporaryPassword: DEFAULT_PASSWORD,
            MessageAction: 'SUPPRESS', 
            UserAttributes: [
                { Name: 'email', Value: username },
                { Name: 'name', Value: name },
                { Name: 'email_verified', Value: 'true' } 
            ],
        };

        try {
            await cognitoClient.send(new AdminCreateUserCommand(adminCreateUserParams));
            console.log('Cognito user created successfully for:', username);
        } catch (cognitoCreateError) {
            if (cognitoCreateError.name === 'UsernameExistsException') {
                console.warn(`Cognito user ${username} already exists. Attempting to add to group if not already there.`);
            } else {
                console.error('Error creating Cognito user:', cognitoCreateError);
                throw new Error(`Failed to create Cognito user: ${cognitoCreateError.message}`);
            }
        }

        console.log(`Adding user ${username} to group ${groupName}`);
        const addUserToGroupParams = {
            GroupName: groupName,
            UserPoolId: userPoolId,
            Username: username,
        };
        await cognitoClient.send(new AdminAddUserToGroupCommand(addUserToGroupParams));
        console.log(`User ${username} added to group ${groupName} successfully.`);

        // --- SES Email Sending Logic ---
        const senderEmail = process.env.SES_SENDER_EMAIL;
        
        if (!senderEmail) {
            console.log('[SES] SES_SENDER_EMAIL not configured. Skipping email notification.');
        } else {
            console.log(`[SES Debug] Preparing to send approval email to ${username}.`);
            
            // Generate email content using the new function
            const { htmlTemplate, textTemplate } = generateApprovalEmailContent(name, username, DEFAULT_PASSWORD, HACKHUB_LOGIN_LINK);
            
            const sendEmailParams = {
                Source: senderEmail, 
                Destination: {
                    ToAddresses: [username], 
                },
                Message: {
                    Subject: {
                        Charset: "UTF-8",
                        Data: "Hackathon Registration Approved! Your Login Details",
                    },
                    Body: {
                        Html: {
                            Charset: "UTF-8",
                            Data: htmlTemplate,
                        },
                        Text: { 
                            Charset: "UTF-8",
                            Data: textTemplate,
                        },
                    },
                },
                ConfigurationSetName: "my-first-configuration-set",
            };

            console.log(`[SES Debug] Sending email with params (excluding body content for brevity):`);
            console.log(`[SES Debug] Source: ${sendEmailParams.Source}`);
            console.log(`[SES Debug] Destination: ${JSON.stringify(sendEmailParams.Destination)}`);
            console.log(`[SES Debug] Subject: ${sendEmailParams.Message.Subject.Data}`);
            
            try {
                const sesResponse = await sesClient.send(new SendEmailCommand(sendEmailParams));
                console.log(`[SES Debug] SES SendEmailCommand successful.`);
                console.log(`Approval email sent successfully to ${username}. MessageId: ${sesResponse.MessageId}`);
            } catch (sesError) {
                console.error(`[SES Debug] Failed to send approval email to ${username}:`, sesError);
                // Log the error but do not re-throw, as email sending might be considered non-critical
            }
        }
        // --- End SES Email Sending Logic ---

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Cognito user created/managed and email sent successfully.' }),
        };

    } catch (error) {
        console.error('Error in cognito-user-manager Lambda:', error);
        throw new Error(`Cognito operation failed: ${error.message}`);
    }
};
