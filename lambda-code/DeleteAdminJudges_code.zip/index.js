// delete-admin-judges/index.js - NEW Lambda function
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing from environment variables.");
    }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) {
        return JSON.parse(data.SecretString);
    }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.connection) {
        try { await cachedConnection.ping(); return cachedConnection; } catch (pingError) {
            console.warn('Cached connection is stale. Reconnecting.', pingError.message);
            try { if (cachedConnection.connection) await cachedConnection.connection.end(); } catch (e) { console.error('Error closing stale connection:', e); }
            cachedConnection = null;
        }
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        const judgeId = event.pathParameters?.judgeId;
        if (!judgeId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing judgeId in path parameters.' }),
            };
        }

        connection = await connectToDatabase();
        const [result] = await connection.execute('DELETE FROM Judge WHERE judge_id = ?', [judgeId]);

        if (result.affectedRows === 0) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Judge not found.' }),
            };
        }

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Judge deleted successfully', judgeId: judgeId }),
        };
    } catch (error) {
        console.error('Error deleting judge:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to delete judge', error: error.message }),
        };
    }
};