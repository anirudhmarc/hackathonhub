// PostProblemTeam/index.js - NEW LAMBDA for POST /participant/problem
const mysql = require("mysql2/promise");
const AWS = require("aws-sdk");
const secretsManager = new AWS.SecretsManager();

// Environment variables
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || "3306", 10);

let cachedConnection = null;

async function getDbCredentials() {
  if (!DB_SECRET_ARN) {
    throw new Error("Database secret ARN is missing.");
  }
  const data = await secretsManager
    .getSecretValue({ SecretId: DB_SECRET_ARN })
    .promise();
  if ("SecretString" in data) {
    return JSON.parse(data.SecretString);
  }
  throw new Error("SecretString not found in Secrets Manager response.");
}

async function connectToDatabase() {
  if (
    cachedConnection &&
    cachedConnection.isValid &&
    cachedConnection.isValid()
  ) {
    console.log("Using cached database connection.");
    return cachedConnection;
  }
  const creds = await getDbCredentials();
  const connection = await mysql.createConnection({
    host: DB_HOST,
    user: creds.username,
    password: creds.password,
    database: DB_DATABASE,
    port: DB_PORT,
  });
  cachedConnection = connection;
  return connection;
}

exports.handler = async (event) => {
  let connection;
  try {
    const token = event.headers.Authorization?.split(" ")[1]; // Expect token for authorization
    if (!token) {
      return {
        statusCode: 401,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ message: "Authorization token missing." }),
      };
    }

    const userEmail = event.requestContext.authorizer.claims.email; // Get user email from Cognito Authorizer
    const userGroups =
      event.requestContext.authorizer.claims["cognito:groups"] || [];
    const isParticipant = userGroups.includes("Participants");

    if (!isParticipant) {
      return {
        statusCode: 403,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: "Forbidden. User is not a participant.",
        }),
      };
    }

    const body = JSON.parse(event.body);
    const { problemId } = body; // Expect problemId from the frontend

    if (!problemId) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ message: "Missing required field: problemId." }),
      };
    }

    connection = await connectToDatabase();
    await connection.beginTransaction();

    // 1. Get leader_id and team_id for the current user
    const [leaderRows] = await connection.execute(
      "SELECT leader_id FROM Leader WHERE email_address = ?",
      [userEmail]
    );
    if (leaderRows.length === 0) {
      await connection.rollback();
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: "Leader not found. Please register a team first.",
        }),
      };
    }
    const leaderId = leaderRows[0].leader_id;

    const [teamRows] = await connection.execute(
      "SELECT team_id, problem_id FROM Team WHERE leader_id = ?",
      [leaderId]
    );
    if (teamRows.length === 0) {
      await connection.rollback();
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message:
            "Team not found for this leader. Please register a team first.",
        }),
      };
    }
    const teamId = teamRows[0].team_id;
    const currentProblemId = teamRows[0].problem_id;

    if (currentProblemId) {
      await connection.rollback();
      return {
        statusCode: 409, // Conflict
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: "Your team has already selected a problem statement.",
        }),
      };
    }

    // 2. Check problem statement and available slots before updating
    const [problemInfoRows] = await connection.execute(
      `SELECT problem_title, problem_max_slots FROM Problem_Statement WHERE problem_id = ?`,
      [problemId]
    );
    if (problemInfoRows.length === 0) {
      await connection.rollback();
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: `Problem with ID ${problemId} not found.`,
        }),
      };
    }
    const problemInfo = problemInfoRows[0];

    const [currentSlotsRows] = await connection.execute(
      `SELECT COUNT(*) AS current_teams FROM Team WHERE problem_id = ?`,
      [problemId]
    );
    const currentTeams = currentSlotsRows[0].current_teams;

    if (currentTeams >= problemInfo.problem_max_slots) {
      await connection.rollback();
      return {
        statusCode: 400, // Bad Request
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: `The problem "${problemInfo.problem_title}" is full. Max slots: ${problemInfo.problem_max_slots}.`,
        }),
      };
    }

    // 3. Update the Team table with the selected problem_id
    await connection.execute(
      "UPDATE Team SET problem_id = ? WHERE team_id = ?",
      [problemId, teamId]
    );
    console.log(`Team ${teamId} selected problem ${problemId}`);

    await connection.commit();

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        message: "Problem selected successfully",
        problemId: problemId,
        teamId: teamId,
      }),
    };
  } catch (error) {
    if (connection) {
      await connection.rollback();
    }
    console.error("Error selecting problem in PostProblemTeam:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        message: "Failed to select problem",
        error: error.message,
      }),
    };
  } finally {
    // Connection handling
    if (connection) {
      connection.end();
    }
  }
};
