// GetStudentSubmission/index.js - Lambda for GET /participant/submission
import mysql from 'mysql2/promise';
import AWS from 'aws-sdk';
const secretsManager = new AWS.SecretsManager();
const s3 = new AWS.S3({ region: process.env.REGION || 'ap-southeast-2' });

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);
const S3_BUCKET_NAME = process.env.S3_BUCKET_NAME;

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        return cachedConnection;
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

async function getPresignedUrl(s3UrlOrKey) {
    if (!s3UrlOrKey || !S3_BUCKET_NAME) return s3UrlOrKey;

    let s3Key = s3UrlOrKey;
    if (s3UrlOrKey.startsWith('https://')) {
        try {
            const url = new URL(s3UrlOrKey);
            s3Key = url.pathname.startsWith('/') ? url.pathname.slice(1) : url.pathname;
        } catch (e) {
            // use as-is
        }
    }

    try {
        return await s3.getSignedUrlPromise('getObject', {
            Bucket: S3_BUCKET_NAME,
            Key: s3Key,
            Expires: 3600,
        });
    } catch (error) {
        console.error('Failed to generate presigned URL for:', s3Key, error.message);
        return s3UrlOrKey;
    }
}

export const handler = async (event) => {
    let connection;
    try {
        const token = event.headers.Authorization?.split(' ')[1];
        if (!token) {
            return {
                statusCode: 401,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Authorization token missing.' }),
            };
        }

        const userEmail = event.requestContext.authorizer.claims.email;
        const userGroups = event.requestContext.authorizer.claims['cognito:groups'] || [];
        const isParticipant = userGroups.includes('Participants');

        if (!isParticipant) {
            return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Forbidden. User is not a participant.' }),
            };
        }

        connection = await connectToDatabase();

        const [leaderRows] = await connection.execute('SELECT leader_id FROM Leader WHERE email_address = ?', [userEmail]);
        if (leaderRows.length === 0) {
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ submission: null, message: 'Leader not found, no submission possible.' }),
            };
        }
        const leaderId = leaderRows[0].leader_id;

        const [teamRows] = await connection.execute('SELECT team_id, problem_id FROM Team WHERE leader_id = ?', [leaderId]);
        if (teamRows.length === 0) {
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ submission: null, message: 'Team not found for this leader.' }),
            };
        }
        const teamId = teamRows[0].team_id;
        const problemId = teamRows[0].problem_id;

        const [submissionRows] = await connection.execute(
            `SELECT
                submission_id, team_id, last_updated,
                submission_video_url, github_url,
                submission_project_description,
                submission_additional_materials_url
            FROM Team_Submission
            WHERE team_id = ?
            ORDER BY last_updated DESC
            LIMIT 1`,
            [teamId]
        );

        let submission = null;
        if (submissionRows.length > 0) {
            submission = submissionRows[0];

            // Generate presigned URL for video
            if (submission.submission_video_url) {
                submission.submission_video_url = await getPresignedUrl(submission.submission_video_url);
            }

            // Handle additional materials (JSON array of URLs)
            if (submission.submission_additional_materials_url && typeof submission.submission_additional_materials_url === 'string') {
                try {
                    const urls = JSON.parse(submission.submission_additional_materials_url);
                    if (Array.isArray(urls)) {
                        submission.submission_additional_materials_url = await Promise.all(
                            urls.map(url => getPresignedUrl(url))
                        );
                    }
                } catch (e) {
                    console.error('Failed to parse submission_additional_materials_url:', e);
                    submission.submission_additional_materials_url = [];
                }
            } else if (!submission.submission_additional_materials_url) {
                submission.submission_additional_materials_url = [];
            }
        }

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ submission: submission, teamId: teamId, problemId: problemId }),
        };
    } catch (error) {
        console.error('Error in GetStudentSubmission handler:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to retrieve submission', error: error.message }),
        };
    } finally {
        if (connection) {
            try { await connection.end(); } catch (err) { console.error('Failed to close connection:', err); }
        }
    }
};
