// post-admin-judges/index.js - Creates judge in DB + invokes CognitoUserManager for account

import mysql from 'mysql2/promise';
import AWS from 'aws-sdk';
import { v4 as uuidv4 } from 'uuid';
import { LambdaClient, InvokeCommand } from '@aws-sdk/client-lambda';

const secretsManager = new AWS.SecretsManager();
const lambdaClient = new LambdaClient({ region: process.env.REGION || 'ap-southeast-2' });

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

const COGNITO_USER_POOL_ID = process.env.COGNITO_USER_POOL_ID;
const COGNITO_MANAGER_FUNCTION = process.env.COGNITO_MANAGER_FUNCTION || 'hackhub-test-13-prod-CognitoUserManager';

let cachedConnection = null;

async function getDbCredentials() {
  if (!DB_SECRET_ARN) {
    throw new Error("Database secret ARN is missing from environment variables.");
  }
  const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
  if ('SecretString' in data) {
    return JSON.parse(data.SecretString);
  }
  throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
  if (cachedConnection && cachedConnection.connection) {
    try { await cachedConnection.ping(); return cachedConnection; } catch (pingError) {
      console.warn('Cached connection is stale. Reconnecting.', pingError.message);
      try { if (cachedConnection.connection) await cachedConnection.connection.end(); } catch (e) { console.error('Error closing stale connection:', e); }
      cachedConnection = null;
    }
  }
  const creds = await getDbCredentials();
  const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
  cachedConnection = connection;
  return connection;
}

async function invokeCognitoManager(email, name, groupName) {
  const payload = {
    userPoolId: COGNITO_USER_POOL_ID,
    username: email,
    name: name,
    groupName: groupName,
  };

  const response = await lambdaClient.send(new InvokeCommand({
    FunctionName: COGNITO_MANAGER_FUNCTION,
    InvocationType: 'RequestResponse',
    Payload: JSON.stringify(payload),
  }));

  const result = JSON.parse(new TextDecoder().decode(response.Payload));
  console.log('CognitoUserManager response:', JSON.stringify(result));
  return result;
}

export const handler = async (event) => {
  let connection;
  try {
    const body = JSON.parse(event.body);
    const { judge_name, email_address } = body;

    if (!judge_name || !email_address) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ message: 'Missing required fields: judge_name, email_address.' }),
      };
    }

    // Step 1: Insert into database
    let judgeId;
    let dbResult = 'created';
    connection = await connectToDatabase();
    try {
      judgeId = uuidv4();
      await connection.execute(
        'INSERT INTO Judge (judge_id, judge_name, email_address) VALUES (?, ?, ?)',
        [judgeId, judge_name, email_address]
      );
    } catch (dbError) {
      if (dbError.code === 'ER_DUP_ENTRY') {
        console.warn(`Judge with email ${email_address} already exists in DB, proceeding to Cognito creation`);
        const [rows] = await connection.execute(
          'SELECT judge_id FROM Judge WHERE email_address = ?',
          [email_address]
        );
        judgeId = rows[0]?.judge_id;
        dbResult = 'already_exists';
      } else {
        throw dbError;
      }
    }

    // Step 2: Invoke CognitoUserManager (non-VPC Lambda) for Cognito account creation
    let cognitoResult = {};
    try {
      cognitoResult = await invokeCognitoManager(email_address, judge_name, 'Judges');
      console.log('Cognito account ensured for judge:', judge_name);
    } catch (cognitoError) {
      console.error('CognitoUserManager invocation failed:', cognitoError);
      cognitoResult = { warning: `Cognito creation failed: ${cognitoError.message}` };
    }

    return {
      statusCode: dbResult === 'created' ? 201 : 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({
        message: dbResult === 'created' ? 'Judge created successfully' : 'Judge already exists, Cognito account ensured',
        judgeId: judgeId,
        cognito: cognitoResult,
      }),
    };
  } catch (error) {
    console.error('Error creating judge:', error);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ message: 'Failed to create judge', error: error.message }),
    };
  }
};
