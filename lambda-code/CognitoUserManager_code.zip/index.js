// cognito-user-manager/index.js
// This Lambda function is deployed OUTSIDE of a VPC
// to allow it to directly access AWS Cognito's public endpoints.

import {
  CognitoIdentityProviderClient,
  AdminCreateUserCommand,
  AdminSetUserPasswordCommand,
  AdminAddUserToGroupCommand,
  AdminDeleteUserCommand
} from "@aws-sdk/client-cognito-identity-provider";

const cognitoClient = new CognitoIdentityProviderClient({
  region: process.env.REGION || "ap-southeast-2"
});

const DEFAULT_PASSWORD = 'HackHub2026!';

async function createUser(event) {
    const { userPoolId, username, name, groupName } = event;

    if (!userPoolId || !username || !name || !groupName) {
        return { statusCode: 400, body: JSON.stringify({ message: 'Missing required parameters: userPoolId, username, name, groupName' }) };
    }

    // 1. Create Cognito user
    try {
        await cognitoClient.send(new AdminCreateUserCommand({
            UserPoolId: userPoolId,
            Username: username,
            TemporaryPassword: DEFAULT_PASSWORD,
            MessageAction: 'SUPPRESS',
            UserAttributes: [
                { Name: 'email', Value: username },
                { Name: 'name', Value: name },
                { Name: 'email_verified', Value: 'true' }
            ],
        }));
        console.log('Cognito user created for:', username);
    } catch (createError) {
        if (createError.name === 'UsernameExistsException') {
            console.warn(`Cognito user ${username} already exists, ensuring group membership`);
        } else {
            throw createError;
        }
    }

    // 2. Set permanent password
    try {
        await cognitoClient.send(new AdminSetUserPasswordCommand({
            UserPoolId: userPoolId,
            Username: username,
            Password: DEFAULT_PASSWORD,
            Permanent: true,
        }));
        console.log('Password set to permanent for:', username);
    } catch (pwError) {
        console.warn('Failed to set permanent password for', username, pwError.message);
    }

    // 3. Add to group
    await cognitoClient.send(new AdminAddUserToGroupCommand({
        GroupName: groupName,
        UserPoolId: userPoolId,
        Username: username,
    }));
    console.log(`User ${username} added to group ${groupName}`);

    return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Cognito user created/managed successfully', email: username, group: groupName }),
    };
}

async function deleteUser(event) {
    const { userPoolId, username } = event;

    if (!userPoolId || !username) {
        return { statusCode: 400, body: JSON.stringify({ message: 'Missing required parameters: userPoolId, username' }) };
    }

    try {
        await cognitoClient.send(new AdminDeleteUserCommand({
            UserPoolId: userPoolId,
            Username: username,
        }));
        console.log('Cognito user deleted:', username);
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Cognito user deleted successfully', email: username }),
        };
    } catch (error) {
        if (error.name === 'UserNotFoundException') {
            console.warn(`Cognito user ${username} not found, nothing to delete`);
            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'Cognito user not found (already deleted)', email: username }),
            };
        }
        throw error;
    }
}

export const handler = async (event) => {
    console.log('Received event for Cognito user management:', JSON.stringify(event));

    try {
        if (event.action === 'delete') {
            return await deleteUser(event);
        }
        return await createUser(event);
    } catch (error) {
        console.error('Error in cognito-user-manager:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: `Cognito operation failed: ${error.message}` }),
        };
    }
};
