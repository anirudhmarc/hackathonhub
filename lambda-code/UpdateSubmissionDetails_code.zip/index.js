import { v4 as uuidv4 } from 'uuid';
import mysql from 'mysql2/promise'; // Changed this line
import AWS from 'aws-sdk'; // Changed this line
const secretsManager = new AWS.SecretsManager();
// You need to keep the old line for secretsManager because it is not a direct import

// Environment variables
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        console.log('Using cached database connection.');
        return cachedConnection;
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

export const handler = async (event) => { // Changed this line
    let connection;
    try {
        const token = event.headers.Authorization?.split(' ')[1];
        if (!token) {
            return {
                statusCode: 401,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Authorization token missing.' }),
            };
        }

        const userEmail = event.requestContext.authorizer.claims.email;
        const userGroups = event.requestContext.authorizer.claims['cognito:groups'] || [];
        const isParticipant = userGroups.includes('Participants');
        
        if (!isParticipant) {
             return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Forbidden. User is not a participant.' }),
            };
        }

        const body = JSON.parse(event.body);
        const { videoUrl, gitlabUrl, projectDescription, additionalMaterialsUrls, teamId, problemId } = body;

        if (!teamId || !videoUrl || !gitlabUrl || !projectDescription || !problemId || !Array.isArray(additionalMaterialsUrls)) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing required fields: teamId, videoUrl, gitlabUrl, projectDescription, problemId, additionalMaterialsUrls.' }),
            };
        }

        connection = await connectToDatabase();
        await connection.beginTransaction();

        const [leaderRows] = await connection.execute('SELECT leader_id FROM Leader WHERE email_address = ?', [userEmail]);
        if (leaderRows.length === 0) {
            await connection.rollback();
            return { statusCode: 404, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ message: 'Leader not found.' }) };
        }
        const leaderId = leaderRows[0].leader_id;

        const [teamRows] = await connection.execute('SELECT team_id, problem_id FROM Team WHERE leader_id = ? AND team_id = ? AND problem_id = ?', [leaderId, teamId, problemId]);
        if (teamRows.length === 0) {
            await connection.rollback();
            return { statusCode: 403, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ message: 'Team ID or Problem ID mismatch for this user.' }) };
        }

        const [existingSubmission] = await connection.execute(
            'SELECT submission_id FROM Team_Submission WHERE team_id = ?',
            [teamId]
        );

        const submissionId = existingSubmission.length > 0 ? existingSubmission[0].submission_id : uuidv4();
        const lastUpdated = new Date().toISOString().slice(0, 19).replace('T', ' ');

        const additionalMaterialsUrlsJson = JSON.stringify(additionalMaterialsUrls);

        if (existingSubmission.length > 0) {
            await connection.execute(
                `UPDATE Team_Submission SET
                    last_updated = ?,
                    submission_video_url = ?,
                    github_url = ?,
                    submission_project_description = ?,
                    submission_additional_materials_url = ?
                WHERE submission_id = ?`,
                [lastUpdated, videoUrl, gitlabUrl, projectDescription, additionalMaterialsUrlsJson, submissionId]
            );
            console.log(`Updated submission for team ${teamId}. Submission ID: ${submissionId}`);
        } else {
            await connection.execute(
                `INSERT INTO Team_Submission (
                    submission_id, team_id, last_updated, submission_video_url,
                    github_url, submission_project_description, submission_additional_materials_url
                ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [submissionId, teamId, lastUpdated, videoUrl, gitlabUrl, projectDescription, additionalMaterialsUrlsJson]
            );
            console.log(`Created new submission for team ${teamId}. Submission ID: ${submissionId}`);
        }
        
        await connection.commit();

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Submission confirmed successfully', submissionId: submissionId, teamId: teamId }),
        };
    } catch (error) {
        if (connection) { await connection.rollback(); }
        console.error('Error in UpdateSubmissionDetails handler:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to confirm submission', error: error.message }),
        };
    } finally {
        if (connection) {
            try {
                await connection.end();
                console.log('Database connection closed.');
            } catch (err) {
                console.error('Failed to close database connection:', err);
            }
        }
    }
};