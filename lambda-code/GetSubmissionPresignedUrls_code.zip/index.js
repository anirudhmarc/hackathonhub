// GetSubmissionPresignedUrls/index.js - MODIFIED to remove ACL
const AWS = require('aws-sdk');
const s3 = new AWS.S3({ region: process.env.REGION });

// Environment variables
const S3_BUCKET_NAME = process.env.S3_BUCKET_NAME;
const REGION = process.env.REGION;

exports.handler = async (event) => {
    try {
        const token = event.headers.Authorization?.split(' ')[1];
        if (!token) {
            return {
                statusCode: 401,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Authorization token missing.' }),
            };
        }

        const userEmail = event.requestContext.authorizer.claims.email;
        const userGroups = event.requestContext.authorizer.claims['cognito:groups'] || [];
        const isParticipant = userGroups.includes('Participants');
        
        if (!isParticipant) {
             return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Forbidden. User is not a participant.' }),
            };
        }

        const body = JSON.parse(event.body);
        const { teamId, files } = body;

        if (!teamId || !Array.isArray(files) || files.length === 0) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing required fields: teamId, files (array of {fileName, fileType, category}).' }),
            };
        }

        const generatedUrls = await Promise.all(files.map(async (file) => {
            let s3KeyPrefix = '';
            if (file.category === 'video') {
                s3KeyPrefix = `submissions/${teamId}/video`;
            } else if (file.category === 'additional') {
                s3KeyPrefix = `submissions/${teamId}/additional-materials`;
            } else {
                throw new Error(`Invalid file category: ${file.category}`);
            }

            const s3Key = `${s3KeyPrefix}/${file.fileName}`;
            
            const params = {
                Bucket: S3_BUCKET_NAME,
                Key: s3Key,
                Expires: 300, // URL expires in 5 minutes
                ContentType: file.fileType,
                // --- CRITICAL FIX: REMOVE this line if your bucket does not allow ACLs ---
                // ACL: 'public-read' 
            };

            const presignedUrl = await s3.getSignedUrlPromise('putObject', params);
            const fileUrl = `https://${S3_BUCKET_NAME}.s3.${REGION}.amazonaws.com/${s3Key}`; // Public URL

            return { fileName: file.fileName, category: file.category, presignedUrl, fileUrl };
        }));

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ urls: generatedUrls }),
        };

    } catch (error) {
        console.error('Error in GetSubmissionPresignedUrls handler:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ message: 'Failed to get presigned URLs', error: error.message }),
        };
    }
};