// FIXED GetJudgeTeams Lambda - Returns ALL teams, not just those with submissions
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let connectionPool = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing.");
    }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) {
        return JSON.parse(data.SecretString);
    }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (!connectionPool) {
        const creds = await getDbCredentials();
        connectionPool = mysql.createPool({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Database connection pool created.');
    }
    return connectionPool.getConnection();
}

exports.handler = async (event) => {
    let connection;
    try {
        const stageId = event.queryStringParameters?.stage_id;
        
        connection = await connectToDatabase();
        
        // FIXED: Changed to LEFT JOIN so teams without submissions are included
        let sqlQuery = `
            SELECT
                t.team_id AS id,
                t.team_name AS name,
                t.is_finalist,
                ps.problem_id,
                ps.problem_title AS problem_statement,
                track.track_title AS track,
                ts.submission_video_url,
                ts.submission_project_description,
                ts.github_url,
                ts.submission_additional_materials_url,
                ts.last_updated,
                ts.submission_id
            FROM Team t
            LEFT JOIN Team_Submission ts ON t.team_id = ts.team_id
            LEFT JOIN Leader l ON t.leader_id = l.leader_id
            LEFT JOIN Track track ON l.track_id = track.track_id
            LEFT JOIN Problem_Statement ps ON t.problem_id = ps.problem_id
            WHERE 1=1
        `;
        
        const queryParams = [];

        // For the second stage, only show finalist teams
        if (stageId && stageId.includes('stage-2')) {
            sqlQuery += ` AND t.is_finalist = ?`;
            queryParams.push(1);
        }

        sqlQuery += ` ORDER BY t.team_name ASC`;

        const [teams] = await connection.execute(sqlQuery, queryParams);
        
        console.log('✅ FIXED LAMBDA - Total teams returned:', teams.length);
        console.log('✅ Teams with submissions:', teams.filter(t => t.submission_video_url).length);
        console.log('✅ Teams without submissions:', teams.filter(t => !t.submission_video_url).length);
        
        // Format the response
        const formattedTeams = teams.map(team => ({
            id: team.id,
            name: team.name,
            is_finalist: team.is_finalist === 1,
            problem_id: team.problem_id,
            problem_statement: team.problem_statement,
            track: team.track || 'unknown',
            submission_video_url: team.submission_video_url || null,
            submission_project_description: team.submission_project_description || null,
            github_url: team.github_url || null,
            submission_additional_materials_url: team.submission_additional_materials_url || null,
            last_updated: team.last_updated ? team.last_updated.toISOString() : null
        }));

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify(formattedTeams)
        };
    } catch (error) {
        console.error('Error fetching teams:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({ error: 'Failed to fetch teams', details: error.message })
        };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};
