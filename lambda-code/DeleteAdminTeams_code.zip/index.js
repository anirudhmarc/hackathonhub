// delete-admin-teams/index.js
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

// Env vars (same as other Lambdas)
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing from environment variables.");
    }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) {
        return JSON.parse(data.SecretString);
    }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.connection) {
        try {
            await cachedConnection.ping();
            return cachedConnection;
        } catch (pingError) {
            console.warn('Cached connection is stale. Reconnecting.', pingError.message);
            try { if (cachedConnection.connection) await cachedConnection.connection.end(); } catch (e) { console.error('Error closing stale connection:', e); }
            cachedConnection = null;
        }
    }

    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({
        host: DB_HOST,
        user: creds.username,
        password: creds.password,
        database: DB_DATABASE,
        port: DB_PORT
    });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        console.log('Received event:', JSON.stringify(event));

        const teamId = event.pathParameters?.teamId; // Get teamId from path parameters
        if (!teamId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing teamId in path parameters.' }),
            };
        }

        connection = await connectToDatabase();
        await connection.beginTransaction();

        // CRITICAL: Handle foreign key constraints - delete dependent records first
        // Delete from Score (if it references Team)
        await connection.execute('DELETE FROM Score WHERE team_id = ?', [teamId]);
        console.log(`Deleted scores for team ${teamId}.`);

        // Delete from Team_Submission (if it references Team)
        await connection.execute('DELETE FROM Team_Submission WHERE team_id = ?', [teamId]);
        console.log(`Deleted submissions for team ${teamId}.`);

        // Then delete the team itself
        const [result] = await connection.execute('DELETE FROM Team WHERE team_id = ?', [teamId]);
        console.log(`Deleted team with ID: ${teamId}, Affected Rows: ${result.affectedRows}`);

        await connection.commit();

        if (result.affectedRows === 0) {
            return {
                statusCode: 404, // Not found if teamId doesn't exist or already deleted
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Team not found or already deleted.' }),
            };
        }

        return {
            statusCode: 204, // 204 No Content for successful deletion
            headers: { 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Team deleted successfully' }),
        };

    } catch (error) {
        if (connection) {
            try {
                await connection.rollback();
                console.log('Transaction rolled back due to error.');
            } catch (rollbackError) {
                console.error('Error during transaction rollback:', rollbackError);
            }
        }
        console.error('Error deleting team:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to delete team', error: error.message }),
        };
    } finally {
        // Connection is typically handled by caching.
    }
};