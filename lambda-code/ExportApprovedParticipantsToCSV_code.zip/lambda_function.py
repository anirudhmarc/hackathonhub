import json
import boto3
import csv
import io
import decimal
from boto3.dynamodb.conditions import Attr

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('HackathonRegistrations')
    
    def get_value(data, key):
        if isinstance(data, dict):
            value = data.get(key)
        else:
            value = data
        
        if isinstance(value, decimal.Decimal):
            value = str(value)
            
        return str(value) if value is not None and str(value).strip() != '' else '-'
        
    FIXED_PERSON_SUB_KEYS = [
        'name', 'email', 'mobile', 'tshirtSize', 'nationality', 'ethnic', 'gender', 'pwd', 
        'bumiputera', 'foodOption', 'foodAllergy', 'university', 'studentId', 'programme', 
        'levelOfStudy', 'year', 'expectedGraduationYear'
    ]
    
    filter_expression = Attr('status').eq('APPROVED')
    
    response = table.scan(FilterExpression=filter_expression)
    all_items = response['Items']
    
    while 'LastEvaluatedKey' in response:
        response = table.scan(
            FilterExpression=filter_expression,
            ExclusiveStartKey=response['LastEvaluatedKey']
        )
        all_items.extend(response['Items'])
    
    
    simple_keys = set()
    max_members = 0
    
    processed_records = []
    
    for item in all_items:
        record = {}
        current_item_member_count = 0
        
        for key, value in item.items():
            if key == 'leader':
                try:
                    record['leader'] = json.loads(get_value(item, 'leader'))
                except (json.JSONDecodeError, TypeError):
                    record['leader'] = {}
            
            elif key == 'members':
                try:
                    members_list = json.loads(get_value(item, 'members'))
                    record['members'] = members_list
                    current_item_member_count = len(members_list)
                except (json.JSONDecodeError, TypeError):
                    record['members'] = []
            
            else:
                simple_keys.add(key)
                record[key] = value

        if current_item_member_count > max_members:
            max_members = current_item_member_count
            
        processed_records.append(record)
        
    simple_keys.discard('leader')
    simple_keys.discard('members')
    simple_keys.discard('memberCount')
    simple_keys.discard('emails')

    sorted_simple_keys = sorted(list(simple_keys))
    
    header = []
    
    header.extend(sorted_simple_keys)
    
    for sub_key in FIXED_PERSON_SUB_KEYS:
        header.append(f'Leader - {sub_key}')
        
    for i in range(1, max_members + 1):
        for sub_key in FIXED_PERSON_SUB_KEYS:
            header.append(f'Member {i} - {sub_key}')

    output = io.StringIO()
    csv_writer = csv.writer(output)
    csv_writer.writerow(header)
    
    for record in processed_records:
        row_data = []
        
        for key in sorted_simple_keys:
            row_data.append(get_value(record.get(key), None)) 
        
        leader_data = record.get('leader', {})
        for sub_key in FIXED_PERSON_SUB_KEYS:
            row_data.append(get_value(leader_data, sub_key))
            
        members_data = record.get('members', [])
        
        for member in members_data:
            for sub_key in FIXED_PERSON_SUB_KEYS:
                row_data.append(get_value(member, sub_key))
                
        padding_needed = (max_members - len(members_data)) * len(FIXED_PERSON_SUB_KEYS)
        if padding_needed > 0:
            row_data.extend(['-'] * padding_needed)

        csv_writer.writerow(row_data)

    csv_content = output.getvalue()
    
    s3 = boto3.client('s3')
    bucket_name = 'participants-dynambodb-data' 
    file_name = 'approved_teams_all_attributes_data.csv'

    max_retries = 3
    delay = 1
    
    for attempt in range(max_retries):
        try:
            s3.put_object(
                Bucket=bucket_name,
                Key=file_name,
                Body=csv_content,
                ContentType='text/csv'
            )
            print(f"Successfully uploaded file to s3://{bucket_name}/{file_name}")
            break
        except Exception as e:
            if attempt < max_retries - 1:
                import time
                print(f"S3 upload failed (attempt {attempt+1}/{max_retries}): {e}. Retrying in {delay}s...")
                time.sleep(delay)
                delay *= 2
            else:
                print(f"S3 upload failed after {max_retries} attempts.")
                raise


    return {
        'statusCode': 200,
        'body': json.dumps(f'CSV file containing all **APPROVED** team, leader, and member attributes has been successfully generated and uploaded to S3 bucket: {bucket_name}!', cls=DecimalEncoder)
    }
