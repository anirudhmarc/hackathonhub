// lambda/certificate-sender/index.js

import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { parse } from 'csv-parse/sync';

// --- Configuration (All loaded from Environment Variables) ---
const SENDER_EMAIL = process.env.SENDER_EMAIL;
const S3_BUCKET_NAME = process.env.S3_BUCKET_NAME;
const CSV_KEY_NAME = process.env.CSV_KEY_NAME;
const RATE_LIMIT_PER_SECOND = parseInt(process.env.RATE_LIMIT_PER_SECOND || 12);
const EXPIRATION_SECONDS = parseInt(process.env.EXPIRATION_SECONDS || 604800); 

// Regions: S3/Lambda uses CUSTOM_AWS_REGION, SES uses SES_REGION
const CUSTOM_REGION = process.env.CUSTOM_AWS_REGION || "ap-southeast-5"; 
const SES_REGION = process.env.SES_REGION || "us-east-1"; 

// CSV Column Headers (Flexible)
const NAME_COLUMN = process.env.NAME_COLUMN || 'Name';
const EMAIL_COLUMN = process.env.EMAIL_COLUMN || 'Email Address';
const KEY_COLUMN = process.env.KEY_COLUMN || 'Certificate Key (S3 Filename)';


// Initialize clients
const s3Client = new S3Client({ region: CUSTOM_REGION }); 
const sesClient = new SESClient({ region: SES_REGION });   


// Utility function to introduce a delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to fetch and parse CSV from S3
const fetchRecipientsFromS3 = async () => {
    try {
        const { Body } = await s3Client.send(new GetObjectCommand({
            Bucket: S3_BUCKET_NAME,
            Key: CSV_KEY_NAME,
        }));

        const csvString = await Body.transformToString();

        const records = parse(csvString, {
            columns: true,
            skip_empty_lines: true,
            trim: true
        });

        // Map to standard keys using the environment variables for column names
        return records.map(record => ({
            name: record[NAME_COLUMN],
            email: record[EMAIL_COLUMN],
            key: record[KEY_COLUMN]
        })).filter(r => r.email && r.key); 

    } catch (error) {
        console.error("Failed to fetch or parse CSV from S3:", error);
        throw new Error(`[S3_DATA_ERROR] Data retrieval failed for ${CSV_KEY_NAME} in bucket ${S3_BUCKET_NAME}.`);
    }
};

// Helper to generate the secure download link with auto-download
const generateCertUrl = async (key) => {
    const command = new GetObjectCommand({
        Bucket: S3_BUCKET_NAME,
        Key: key,
        ResponseContentDisposition: `attachment; filename="${key}"`
    });
    return getSignedUrl(s3Client, command, { expiresIn: EXPIRATION_SECONDS });
};

// Main Lambda Handler
export const handler = async (event) => {
    console.log(`Starting certificate broadcast from Lambda region ${CUSTOM_REGION} via SES region ${SES_REGION}...`);

    // Basic configuration check
    if (!SENDER_EMAIL || !S3_BUCKET_NAME || !CSV_KEY_NAME) {
        return { statusCode: 500, body: JSON.stringify({ message: "Configuration Error: Missing required environment variables." }) };
    }

    // 1. Fetch all recipients from S3 CSV
    let recipients = [];
    try {
        recipients = await fetchRecipientsFromS3();
    } catch (error) {
        return { statusCode: 500, body: JSON.stringify({ message: error.message }) };
    }

    if (recipients.length === 0) {
        return { statusCode: 404, body: JSON.stringify({ message: "No recipients found in the CSV file." }) };
    }

    console.log(`Loaded ${recipients.length} recipients. Rate Limit: ${RATE_LIMIT_PER_SECOND}/s. Link Expiry Set to: ${EXPIRATION_SECONDS}s.`);

    const BATCH_SIZE = RATE_LIMIT_PER_SECOND;
    let successCount = 0;
    let failedCount = 0;
    
    // 2. Process and send emails in batches (Rate-limited logic)
    for (let i = 0; i < recipients.length; i += BATCH_SIZE) {
        const batch = recipients.slice(i, i + BATCH_SIZE);
        
        const emailPromises = batch.map(async (recipient) => {
            try {
                const certUrl = await generateCertUrl(recipient.key);

                // Calculate expiration in hours for the message
                const expirationHours = EXPIRATION_SECONDS / 3600; 

                // Subject uses the exact format requested
                const subject = `Your Great Malaysia AI Hackathon Certificate - ${recipient.name}`;

                // --- START FINAL HTML EMAIL TEMPLATE ---
                const bodyHtml = `
                    <body style="font-family: 'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif; line-height: 1.6; color: #333; background-color: #f5f5f5; margin: 0; padding: 0;">
                        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="table-layout: fixed;">
                            <tr>
                                <td align="center" style="padding: 40px 0;">
                                    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="650" style="max-width: 650px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; border: 1px solid #e0e0e0; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
                                        
                                        <tr>
                                            <td style="background-color: #1c2732; color: #ffffff; padding: 40px 50px; text-align: center; border-bottom: 4px solid #f39c12;">
                                                <p style="font-size: 14px; font-weight: 500; margin: 0 0 5px 0; color: #bbbbbb; letter-spacing: 2px; text-transform: uppercase;">Certificate of Participation</p>
                                                <h1 style="font-size: 30px; font-weight: 700; margin: 0; letter-spacing: 0.8px;">Great Malaysia AI Hackathon</h1>
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td style="padding: 40px 50px; color: #333333;">
                                                <p style="font-size: 16px; line-height: 1.7; margin-top: 0; margin-bottom: 25px;">
                                                    Hello <strong>${recipient.name}</strong>,
                                                </p>
                                                <p style="font-size: 16px; line-height: 1.7; margin-bottom: 35px;">
                                                    Thank you for your dedication! Your personalized <strong>Certificate of Participation</strong> for submitting your hackathon project is ready for download.
                                                </p>
                                                
                                                <p style="font-size: 16px; line-height: 1.7; margin-bottom: 10px; text-align: center; font-weight: bold; color: #1c2732;">
                                                    Click the secure link below to access your certificate:
                                                </p>

                                                <div style="text-align: center; margin: 20px 0 40px 0;">
                                                    <a href="${certUrl}" 
                                                        style="background-color: #f39c12; color: #1c2732; padding: 15px 50px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 18px; display: inline-block; border: 2px solid #e67e22; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
                                                        📥 DOWNLOAD CERTIFICATE
                                                    </a>
                                                </div>
                                                
                                                <div style="background-color: #fef1f0; border-left: 5px solid #b73223; color: #1c2732; padding: 18px; border-radius: 6px;">
                                                    <p style="font-size: 14px; margin: 0; line-height: 1.5;">
                                                        <strong>SECURITY NOTE:</strong> This unique download link will <strong>expire in ${expirationHours} hours</strong>. Please download and save your certificate before the deadline.
                                                    </p>
                                                </div>

                                                <p style="font-size: 16px; line-height: 1.7; margin-top: 35px; margin-bottom: 10px;">
                                                    Congratulations on successfully completing and submitting your project!
                                                </p>
                                                
                                                <p style="font-size: 16px; line-height: 1.7; margin-top: 25px;">
                                                    If you encounter any issues accessing your certificate or have other queries, please chat with us on Discord:
                                                </p>
                                                <div style="text-align: center; margin: 15px 0 25px 0;">
                                                    <a href="https://discord.gg/AMxFj7R6" 
                                                        style="background-color: #5865F2; 
                                                               color: white; 
                                                               padding: 12px 40px; 
                                                               text-decoration: none; 
                                                               border-radius: 8px; 
                                                               font-weight: 700; 
                                                               font-size: 16px; 
                                                               display: inline-block;
                                                               border: 1px solid #454F9D;
                                                               letter-spacing: 0.5px;
                                                               text-transform: uppercase;
                                                               box-shadow: 0 4px 6px rgba(0,0,0,0.15);">
                                                        💬 Chat Discord Support
                                                    </a>
                                                </div>
                                                <p style="font-size: 14px; line-height: 1.7; margin-bottom: 10px;">
                                                    Thank you,
                                                </p>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td style="background-color: #f7f7f7; padding: 30px 50px; text-align: center; border-top: 1px solid #e0e0e0;">
                                                <p style="font-size: 14px; color: #777; margin: 0;">
                                                    Great Malaysia AI Hackathon Organizing team
                                                </p>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </body>
                `;
                // --- END FINAL HTML EMAIL TEMPLATE ---


                const sendEmailParams = {
                    Source: SENDER_EMAIL,
                    Destination: { ToAddresses: [recipient.email] },
                    Message: {
                        Subject: { Charset: "UTF-8", Data: subject },
                        Body: { Html: { Charset: "UTF-8", Data: bodyHtml } }
                    },
                };
                
                await sesClient.send(new SendEmailCommand(sendEmailParams));
                console.log(`✅ Email sent to: ${recipient.email}`);
                successCount++;
                return true;
            } catch (err) {
                // If SES fails, log the specific recipient and error
                console.error(`❌ Failed to send email to ${recipient.email}:`, err);
                failedCount++;
                return false;
            }
        });

        await Promise.allSettled(emailPromises);
        
        // Pause for rate limiting
        if (i + BATCH_SIZE < recipients.length) {
            await delay(1000); // 1 second delay
        }
    }

    const responseMessage = `Certificate delivery completed. ${successCount} emails sent successfully, ${failedCount} failed.`;
    console.log(responseMessage);
    
    return {
        statusCode: 200,
        body: JSON.stringify({ message: responseMessage, totalRecipients: recipients.length, successCount, failedCount }),
    };
};