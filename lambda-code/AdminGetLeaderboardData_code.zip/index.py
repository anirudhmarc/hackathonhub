import json
import os
import pymysql
from decimal import Decimal
import datetime
import boto3

# Cache database connection and credentials
db_connection = None
db_credentials = None
secrets_client = boto3.client('secretsmanager')

class CustomJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles Decimal and datetime objects."""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()
        if isinstance(obj, datetime.date):
            return obj.isoformat()
        return super().default(obj)

def get_db_credentials():
    """Fetch database credentials from Secrets Manager."""
    global db_credentials
    
    if db_credentials:
        return db_credentials
    
    secret_arn = os.environ.get('DB_SECRET_ARN')
    if not secret_arn:
        raise ValueError('DB_SECRET_ARN environment variable not set')
    
    response = secrets_client.get_secret_value(SecretId=secret_arn)
    db_credentials = json.loads(response['SecretString'])
    return db_credentials

def get_db_connection():
    """Establishes and returns a database connection."""
    global db_connection
    
    # Reuse connection if available
    if db_connection:
        try:
            db_connection.ping(reconnect=True)
            return db_connection
        except:
            db_connection = None
    
    # Get credentials from Secrets Manager
    creds = get_db_credentials()
    
    # Parse RDS endpoint
    rds_endpoint = os.environ.get('RDS_ENDPOINT', '')
    if ':' in rds_endpoint:
        db_host, db_port = rds_endpoint.split(':')
        db_port = int(db_port)
    else:
        db_host = rds_endpoint
        db_port = 3306
    
    db_name = os.environ.get('DB_NAME', 'hackhub')
    
    # Create new connection
    db_connection = pymysql.connect(
        host=db_host,
        user=creds['username'],
        password=creds['password'],
        database=db_name,
        port=db_port,
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
        charset='utf8mb4',
        connect_timeout=10
    )
    
    return db_connection

def handler(event, context):
    """Handler for the GET /admin/leaderboard API."""
    print('Event:', json.dumps(event))
    
    conn = None
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Support optional query parameters: judge_id, stage_id, team_id
        qs = event.get('queryStringParameters') or {}
        filter_judge_id = qs.get('judge_id') if qs.get('judge_id') else None
        filter_stage_id = qs.get('stage_id') if qs.get('stage_id') else None
        filter_team_id = qs.get('team_id') if qs.get('team_id') else None
        
        # Fetch teams with track info
        team_query = """
        SELECT
            t.team_id AS id,
            t.team_name AS name,
            t.problem_id AS problem_id,
            ps.problem_title AS problem_title,
            COALESCE(tr.track_title, leader_tr.track_title) AS track_name,
            t.is_finalist
        FROM Team t
        LEFT JOIN Problem_Statement ps ON t.problem_id = ps.problem_id
        LEFT JOIN Track tr ON ps.track_id = tr.track_id
        LEFT JOIN Leader l ON t.leader_id = l.leader_id
        LEFT JOIN Track leader_tr ON l.track_id = leader_tr.track_id
        """
        
        cursor.execute(team_query)
        teams = cursor.fetchall()
        print(f'Fetched {len(teams)} teams')
        
        # Fetch problems
        problem_query = """
        SELECT
            problem_id AS id,
            problem_title AS title
        FROM Problem_Statement
        """
        
        cursor.execute(problem_query)
        problems = cursor.fetchall()
        print(f'Fetched {len(problems)} problems')
        
        # Fetch scores with optional filtering
        scores_query = """
            SELECT
                s.score_id AS id,
                s.team_id,
                s.judge_id,
                j.judge_name AS judge_name,
                s.innovation,
                s.technical_complexity,
                s.impact,
                s.presentation,
                s.aws_funding_vote,
                s.feedback,
                s.strength,
                s.improvement,
                s.last_updated,
                s.stage_id
            FROM Score s
            LEFT JOIN Judge j ON s.judge_id = j.judge_id
        """
        
        where_clauses = []
        params = []
        
        if filter_judge_id:
            where_clauses.append('s.judge_id = %s')
            params.append(filter_judge_id)
        if filter_stage_id:
            where_clauses.append('s.stage_id = %s')
            params.append(filter_stage_id)
        if filter_team_id:
            where_clauses.append('s.team_id = %s')
            params.append(filter_team_id)
        
        if where_clauses:
            scores_query += ' WHERE ' + ' AND '.join(where_clauses)
        
        cursor.execute(scores_query, tuple(params) if params else None)
        scores = cursor.fetchall()
        print(f'Fetched {len(scores)} scores')
        
        # Fetch judging stages
        stages_query = """
            SELECT
                stage_id,
                stage_name
            FROM Judging_Stage
            ORDER BY start_time ASC
        """
        
        cursor.execute(stages_query)
        judging_stages = cursor.fetchall()
        print(f'Fetched {len(judging_stages)} judging stages')
        
        # Fetch judges list
        judges_query = """
            SELECT
                judge_id,
                judge_name,
                email_address
            FROM Judge
        """
        
        cursor.execute(judges_query)
        judges = cursor.fetchall()
        print(f'Fetched {len(judges)} judges')
        
        # Return response
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'GET,OPTIONS'
            },
            'body': json.dumps({
                'teams': teams or [],
                'problems': problems or [],
                'scores': scores or [],
                'judgingStages': judging_stages or [],
                'judges': judges or []
            }, cls=CustomJSONEncoder)
        }
        
    except Exception as error:
        print(f'Error: {str(error)}')
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Internal Server Error',
                'error': str(error)
            })
        }
