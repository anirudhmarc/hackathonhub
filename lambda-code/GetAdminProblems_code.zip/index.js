// get-admin-problems/index.js - MODIFIED to include tracks
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

// Environment variables for connection info
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    console.log('Fetching DB credentials from Secrets Manager...');
    try {
        const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
        if ('SecretString' in data) {
            console.log('Successfully fetched secret from Secrets Manager.');
            return JSON.parse(data.SecretString);
        }
        throw new Error('SecretString not found in Secrets Manager response.');
    } catch (err) {
        console.error('Error retrieving secret from Secrets Manager:', err);
        throw err;
    }
}

async function connectToDatabase() {
    console.log('Checking for cached database connection...');
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        console.log('Using cached database connection.');
        return cachedConnection;
    }

    const creds = await getDbCredentials();
    console.log("Connecting to database with host:", DB_HOST, "user:", creds.username, "database:", DB_DATABASE, "port:", DB_PORT);

    try {
        const connection = await mysql.createConnection({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Successfully established new database connection.');
        cachedConnection = connection;
        return connection;
    } catch (err) {
        console.error('Error establishing database connection:', err);
        throw err;
    }
}

exports.handler = async (event) => {
    let connection;
    try {
        console.log('Received event:', JSON.stringify(event));
        console.log('Attempting to connect to the database...');

        connection = await connectToDatabase();
        console.log('Database connection obtained (new or cached).');

        // --- Fetch Problems Data ---
        console.log('Executing SQL query to fetch problems...');
        
        const trackIdFilter = event.queryStringParameters?.track_id;
        console.log('Filtering by track_id:', trackIdFilter);

        let problemsQuery = `
            SELECT
                ps.problem_id AS id,
                ps.problem_title AS title,
                ps.problem_description AS description,
                ps.problem_tag AS tag,
                ps.problem_max_slots AS max_slots,
                ps.track_id AS track_id, -- Keep original track_id for mapping
                t.track_title AS track_title -- Get track title directly here
            FROM
                Problem_Statement ps
            LEFT JOIN
                Track t ON ps.track_id = t.track_id
        `;
        const problemsQueryParams = [];

        if (trackIdFilter && trackIdFilter !== 'all' && trackIdFilter !== 'admin') {
            problemsQuery += ` WHERE ps.track_id = ?`;
            problemsQueryParams.push(trackIdFilter);
        }

        problemsQuery += ` ORDER BY ps.problem_title ASC`;
        
        const [problemsRows] = await connection.execute(problemsQuery, problemsQueryParams);

        const problemsData = problemsRows.map(row => ({
            id: row.id,
            title: row.title,
            description: row.description,
            tag: row.tag,
            max_slots: row.max_slots, // snake_case from DB
            trackTitle: row.track_title, // from join
            trackId: row.track_id // from DB
        }));
        console.log('Problems data fetched successfully.');

        // --- Fetch Tracks Data ---
        console.log('Executing SQL query to fetch all tracks...');
        const [tracksRows] = await connection.execute(`
            SELECT
                track_id AS id,
                track_title AS title
            FROM
                Track
            ORDER BY track_title ASC
        `);
        const tracksData = tracksRows.map(row => ({ id: row.id, title: row.title }));
        console.log('Tracks data fetched successfully.');


        console.log('Returning successful response with problems and tracks data.');
        return {
            statusCode: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' 
            },
            // --- CRITICAL CHANGE: Return an object containing both arrays ---
            body: JSON.stringify({
                problems: problemsData,
                tracks: tracksData
            }),
        };
    } catch (error) {
        console.error('Error in handler:', error);
        return {
            statusCode: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' 
            },
            body: JSON.stringify({ message: 'Internal server error', error: error.message }),
        };
    } finally {
        // Connection handling (omit connection.end() for caching)
    }
};