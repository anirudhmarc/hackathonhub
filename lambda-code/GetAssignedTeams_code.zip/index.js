const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let connectionPool = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (!connectionPool) {
        const creds = await getDbCredentials();
        connectionPool = mysql.createPool({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0
        });
    }
    return connectionPool.getConnection();
}

exports.handler = async (event) => {
    let connection;
    try {
        const judgeId = event.pathParameters?.judgeId;
        const stageId = event.queryStringParameters?.stage_id;

        console.log('GetAssignedTeams - judgeId:', judgeId, 'stageId:', stageId);

        if (!judgeId || !stageId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing judgeId or stage_id.' }),
            };
        }

        connection = await connectToDatabase();

        // Query to get teams assigned to this judge
        let sqlQuery = `
            SELECT
                t.team_id AS id,
                t.team_name AS name,
                t.is_finalist,
                ps.problem_id,
                ps.problem_title AS problem_statement,
                ts.submission_video_url,
                ts.submission_project_description,
                ts.github_url,
                ts.submission_additional_materials_url,
                track.track_title AS track
            FROM
                Judge_Assignment ja
            JOIN
                Team t ON ja.team_id = t.team_id
            LEFT JOIN
                Leader l ON t.leader_id = l.leader_id
            LEFT JOIN
                Track track ON l.track_id = track.track_id
            LEFT JOIN
                Problem_Statement ps ON t.problem_id = ps.problem_id
            LEFT JOIN
                Team_Submission ts ON t.team_id = ts.team_id
            WHERE
                ja.judge_id = ?
                AND ja.stage_id = ?
        `;

        const queryParams = [judgeId, stageId];

        if (stageId.includes('stage-2')) {
            sqlQuery += ` AND t.is_finalist = ?`;
            queryParams.push(1);
        }

        sqlQuery += ` ORDER BY t.team_name ASC`;

        console.log('Executing query with params:', queryParams);
        const [rows] = await connection.execute(sqlQuery, queryParams);
        console.log('Found', rows.length, 'teams assigned to judge');

        // Fetch scores for these teams from this judge in this stage
        const teamIds = rows.map(row => row.id);
        let scores = [];
        
        if (teamIds.length > 0) {
            const placeholders = teamIds.map(() => '?').join(',');
            const scoresQuery = `
                SELECT
                    s.score_id AS id,
                    s.team_id,
                    s.judge_id,
                    s.innovation,
                    s.technical_complexity,
                    s.impact,
                    s.presentation,
                    s.aws_funding_vote,
                    s.feedback,
                    s.strength,
                    s.improvement,
                    s.last_updated,
                    s.stage_id
                FROM Score s
                WHERE s.team_id IN (${placeholders})
                    AND s.judge_id = ?
                    AND s.stage_id = ?
            `;
            
            const scoresParams = [...teamIds, judgeId, stageId];
            const [scoresRows] = await connection.execute(scoresQuery, scoresParams);
            scores = scoresRows;
        }

        // Map scores to teams
        const scoresMap = {};
        scores.forEach(score => {
            scoresMap[score.team_id] = {
                id: score.id,
                innovation: score.innovation,
                technical_complexity: score.technical_complexity,
                impact: score.impact,
                presentation: score.presentation,
                aws_funding_vote: score.aws_funding_vote,
                feedback: score.feedback,
                strength: score.strength,
                improvement: score.improvement,
                last_updated: score.last_updated
            };
        });

        const teamsData = rows.map(row => ({
            id: row.id,
            name: row.name,
            is_finalist: !!row.is_finalist,
            problem_id: row.problem_id,
            problem_statement: row.problem_statement,
            track: row.track,
            submission_video_url: row.submission_video_url,
            submission_project_description: row.submission_project_description,
            github_url: row.github_url,
            submission_additional_materials_url: row.submission_additional_materials_url,
            score: scoresMap[row.id] || null
        }));

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify(teamsData),
        };
    } catch (error) {
        console.error('Error in handler:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Internal server error', error: error.message }),
        };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};
