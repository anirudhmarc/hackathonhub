const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const secretsManager = new AWS.SecretsManager();

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let connectionPool = null;

async function getDbCredentials() {
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    return JSON.parse(data.SecretString);
}

async function connectToDatabase() {
    if (!connectionPool) {
        const creds = await getDbCredentials();
        connectionPool = mysql.createPool({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Database connection pool created.');
    }
    return connectionPool.getConnection();
}

exports.handler = async (event) => {
    let connection;
    try {
        connection = await connectToDatabase();
        
        const httpMethod = event.httpMethod;
        
        if (!event.body) {
            return {
                statusCode: 400,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ message: 'Request body is missing.' }),
            };
        }
        
        const body = JSON.parse(event.body);
        const { team_id, judge_id, innovation, technical_complexity, impact, presentation, feedback, strength, improvement, aws_funding_vote, stage_id } = body;

        // FIX: Add a validation check for stage_id before submitting the score.
        if (!stage_id) {
             return {
                statusCode: 400,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ message: 'stage_id is required.' }),
            };
        }

        if (httpMethod === 'POST') {
            const scoreId = uuidv4();
            await connection.execute(`
                INSERT INTO Score (score_id, team_id, judge_id, innovation, technical_complexity, impact, presentation, feedback, strength, improvement, aws_funding_vote, stage_id, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            `, [scoreId, team_id, judge_id, innovation, technical_complexity, impact, presentation, feedback, strength, improvement, aws_funding_vote, stage_id]);
            console.log(`Score submitted for team ${team_id} by judge ${judge_id} in stage ${stage_id}`);
            return {
                statusCode: 200,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ message: 'Score submitted successfully', id: scoreId }),
            };
        } else if (httpMethod === 'PUT') {
            await connection.execute(`
                UPDATE Score
                SET innovation = ?, technical_complexity = ?, impact = ?, presentation = ?, feedback = ?, strength = ?, improvement = ?, aws_funding_vote = ?, last_updated = NOW()
                WHERE team_id = ? AND judge_id = ? AND stage_id = ?
            `, [innovation, technical_complexity, impact, presentation, feedback, strength, improvement, aws_funding_vote, team_id, judge_id, stage_id]);
            console.log(`Score updated for team ${team_id} by judge ${judge_id} in stage ${stage_id}`);
            return {
                statusCode: 200,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ message: 'Score updated successfully' }),
            };
        } else {
            return {
                statusCode: 405,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ message: 'Method Not Allowed' }),
            };
        }
    } catch (error) {
        console.error("Failed to process request:", error);
        return {
            statusCode: 500,
            headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ message: "Internal Server Error", error: error.message }),
        };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};
