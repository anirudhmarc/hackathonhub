// create-cognito-user.js
import {
  CognitoIdentityProviderClient,
  AdminCreateUserCommand,
  AdminSetUserPasswordCommand,
  AdminAddUserToGroupCommand
} from '@aws-sdk/client-cognito-identity-provider';

const cognitoIdentityProviderClient = new CognitoIdentityProviderClient({
  region: 'ap-southeast-5'
});

const userPoolId = process.env.USER_POOL_ID;
const JUDGE_GROUP_NAME = 'Judges';

export const handler = async (event) => {
  console.log('Received event for Cognito creation:', JSON.stringify(event, null, 2));

  const { judgeEmail, judgeName, default_password } = event;

  // Validate input
  if (!judgeEmail || !judgeName || !default_password) {
    console.error('Missing required fields:', { judgeEmail, judgeName, default_password });
    return {
      statusCode: 400,
      body: JSON.stringify({
        message: 'Missing required fields: judgeEmail, judgeName, default_password'
      })
    };
  }

  try {
    // 1. Create Cognito user
    const createUserParams = {
      UserPoolId: userPoolId,
      Username: judgeEmail,
      TemporaryPassword: default_password,
      MessageAction: 'SUPPRESS', // Don't send welcome email
      UserAttributes: [
        { Name: 'email', Value: judgeEmail },
        { Name: 'email_verified', Value: 'true' },
        { Name: 'name', Value: judgeName }
      ],
    };

    await cognitoIdentityProviderClient.send(new AdminCreateUserCommand(createUserParams));
    console.log('✅ Cognito user created successfully for judge:', judgeName);

    // 2. Set permanent password
    const setPasswordParams = {
      UserPoolId: userPoolId,
      Username: judgeEmail,
      Password: default_password,
      Permanent: true,
    };
    await cognitoIdentityProviderClient.send(new AdminSetUserPasswordCommand(setPasswordParams));
    console.log('✅ Password set to permanent for judge:', judgeName);

    // 3. Add to Judges group
    const addUserToGroupParams = {
      GroupName: JUDGE_GROUP_NAME,
      UserPoolId: userPoolId,
      Username: judgeEmail,
    };
    await cognitoIdentityProviderClient.send(new AdminAddUserToGroupCommand(addUserToGroupParams));
    console.log('✅ User added to "Judges" group.');

    // ✅ Success response
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Cognito account created, password set, and user added to group.',
        email: judgeEmail,
        name: judgeName
      })
    };

  } catch (error) {
    console.error('❌ Error in Cognito operations:', error);

    let statusCode = 500;
    let message = 'Failed to create Cognito user or add to group.';

    if (error.name === 'UsernameExistsException') {
      statusCode = 409;
      message = 'A user with this email already exists in Cognito.';
    } else if (error.name === 'ResourceNotFoundException') {
      statusCode = 404;
      message = 'User pool or group not found.';
    }

    return {
      statusCode,
      body: JSON.stringify({
        message,
        details: error.message,
        code: error.name || error.code
      })
    };
  }
};