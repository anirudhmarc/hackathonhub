// delete-admin-problems/index.js - FINAL CORRECTED
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.connection) {
        try { await cachedConnection.ping(); return cachedConnection; } catch (e) {
            console.warn('Cached connection is stale. Reconnecting.');
            cachedConnection = null;
        }
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({
        host: DB_HOST,
        user: creds.username,
        password: creds.password,
        database: DB_DATABASE,
        port: DB_PORT
    });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        const problemId = event.pathParameters?.problemId;
        if (!problemId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing problemId in path parameters.' }),
            };
        }
        
        // --- Perbaikan: Hapus baris-baris ini ---
        // const body = JSON.parse(event.body); 
        // const { problem_title, problem_description, problem_tag, problem_max_slots, track_id } = body;
        // --- Akhir perbaikan ---

        connection = await connectToDatabase();
        const [result] = await connection.execute('DELETE FROM Problem_Statement WHERE problem_id = ?', [problemId]);

        if (result.affectedRows === 0) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Problem not found.' }),
            };
        }

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Problem deleted successfully', problemId: problemId }),
        };
    } catch (error) {
        console.error('Error deleting problem:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to delete problem', error: error.message }),
        };
    } finally {
    }
};