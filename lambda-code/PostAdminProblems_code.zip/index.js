// post-admin-problems/index.js - FINAL
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const { v4: uuidv4 } = require('uuid');

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.connection) {
        try { await cachedConnection.ping(); return cachedConnection; } catch (e) {
            console.warn('Cached connection is stale. Reconnecting.');
            cachedConnection = null;
        }
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        const body = JSON.parse(event.body);
        const { problem_title, problem_description, problem_tag, problem_max_slots, track_id } = body;

        if (!problem_title || !problem_description || !problem_max_slots || !track_id) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing required fields: problem_title, problem_description, problem_max_slots, track_id.' }),
            };
        }

        connection = await connectToDatabase();
        const problemId = uuidv4();
        await connection.execute(
            'INSERT INTO Problem_Statement (problem_id, problem_title, problem_description, problem_tag, problem_max_slots, track_id) VALUES (?, ?, ?, ?, ?, ?)',
            [problemId, problem_title, problem_description, problem_tag, problem_max_slots, track_id]
        );

        return {
            statusCode: 201,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Problem created successfully', problemId: problemId }),
        };
    } catch (error) {
        console.error('Error creating problem:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to create problem', error: error.message }),
        };
    }
};