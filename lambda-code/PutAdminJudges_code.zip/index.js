// put-admin-judges/index.js - NEW Lambda function
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const { v4: uuidv4 } = require('uuid');

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing from environment variables.");
    }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) {
        return JSON.parse(data.SecretString);
    }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.connection) {
        try { await cachedConnection.ping(); return cachedConnection; } catch (pingError) {
            console.warn('Cached connection is stale. Reconnecting.', pingError.message);
            try { if (cachedConnection.connection) await cachedConnection.connection.end(); } catch (e) { console.error('Error closing stale connection:', e); }
            cachedConnection = null;
        }
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        const judgeId = event.pathParameters?.judgeId;
        if (!judgeId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing judgeId in path parameters.' }),
            };
        }

        const body = JSON.parse(event.body);
        const { judge_name, email_address } = body;

        if (!judge_name || !email_address) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing required fields: judge_name, email_address.' }),
            };
        }

        connection = await connectToDatabase();
        const [result] = await connection.execute(
            'UPDATE Judge SET judge_name = ?, email_address = ? WHERE judge_id = ?',
            [judge_name, email_address, judgeId]
        );

        if (result.affectedRows === 0) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Judge not found or no changes made.' }),
            };
        }

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Judge updated successfully', judgeId: judgeId }),
        };
    } catch (error) {
        console.error('Error updating judge:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to update judge', error: error.message }),
        };
    }
};