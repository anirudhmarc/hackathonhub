// post-admin-teams/index.js - FINAL (MODIFIED for teamId generation)
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const { v4: uuidv4 } = require('uuid'); // Import UUID generation

// Environment variables for database connection details
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

/**
 * Retrieves database credentials from AWS Secrets Manager.
 * @returns {Promise<{username: string, password: string}>} Database credentials.
 */
async function getDbCredentials() {
    console.log('Fetching DB credentials from Secrets Manager...');
    if (!DB_SECRET_ARN) {
        console.error("DB_SECRET_ARN environment variable is not set. Cannot fetch credentials.");
        throw new Error("Database secret ARN is missing.");
    }
    try {
        const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
        if ('SecretString' in data) {
            const secret = JSON.parse(data.SecretString);
            console.log('Successfully fetched secret from Secrets Manager.');
            return {
                username: secret.username,
                password: secret.password
            };
        }
        throw new Error('SecretString not found in Secrets Manager response.');
    } catch (err) {
        console.error('Error retrieving secret from Secrets Manager:', err);
        throw err;
    }
}

/**
 * Establishes or reuses a database connection.
 * @returns {Promise<mysql.Connection>} A database connection object.
 */
async function connectToDatabase() {
    console.log('Checking for cached database connection...');
    if (cachedConnection && cachedConnection.connection) {
        try {
            await cachedConnection.ping();
            console.log('Using cached database connection (ping successful).');
            return cachedConnection;
        } catch (pingError) {
            console.warn('Cached connection is stale or failed ping. Reconnecting...', pingError.message);
            try {
                if (cachedConnection.connection) await cachedConnection.connection.end();
            } catch (closeError) {
                console.error('Error closing stale cached connection:', closeError);
            }
            cachedConnection = null;
        }
    }

    const creds = await getDbCredentials();
    console.log(`Connecting to database '${DB_DATABASE}' at host: ${DB_HOST} user: ${creds.username} port: ${DB_PORT}`);
    
    try {
        const connection = await mysql.createConnection({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Successfully established new database connection.');
        cachedConnection = connection;
        return connection;
    } catch (err) {
        console.error('Error establishing database connection:', err);
        throw err;
    }
}

/**
 * Main Lambda handler function for POST /admin/teams.
 * @param {Object} event - The Lambda event object (from API Gateway).
 * @returns {Object} - API Gateway compatible response.
 */
exports.handler = async (event) => {
    let connection;
    try {
        console.log('Received event:', JSON.stringify(event));

        const body = JSON.parse(event.body);

        const { team_name, leader_email, problem_id, track_id } = body;

        if (!team_name || !leader_email || !track_id) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing required fields: team_name, leader_email, track_id.' }),
            };
        }

        connection = await connectToDatabase();
        await connection.beginTransaction();
        console.log('Transaction started.');

        const [trackRows] = await connection.execute('SELECT track_id FROM Track WHERE track_id = ?', [track_id]);
        if (trackRows.length === 0) {
            await connection.rollback();
            console.error(`Error: Invalid track_id: ${track_id}. Track not found.`);
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: `Invalid track_id: ${track_id}. Track not found.` }),
            };
        }

        let problemIdToInsert = problem_id || null;
        if (problemIdToInsert) {
            console.log(`Checking slots for problem_id: ${problemIdToInsert}`);
            const [problemInfoRows] = await connection.execute(
                `SELECT problem_title, problem_max_slots FROM Problem_Statement WHERE problem_id = ?`,
                [problemIdToInsert]
            );

            if (problemInfoRows.length === 0) {
                await connection.rollback();
                return {
                    statusCode: 400,
                    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                    body: JSON.stringify({ message: `Problem with ID ${problemIdToInsert} not found.` }),
                };
            }

            const problemInfo = problemInfoRows[0];
            const [currentSlotsRows] = await connection.execute(
                `SELECT COUNT(*) AS current_teams FROM Team WHERE problem_id = ?`,
                [problemIdToInsert]
            );
            const currentTeams = currentSlotsRows[0].current_teams;

            if (currentTeams >= problemInfo.problem_max_slots) {
                await connection.rollback();
                return {
                    statusCode: 400,
                    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                    body: JSON.stringify({ message: `The problem "${problemInfo.problem_title}" is full. Max slots: ${problemInfo.problem_max_slots}.` }),
                };
            }
            console.log(`Problem "${problemInfo.problem_title}" has ${currentTeams}/${problemInfo.problem_max_slots} slots filled.`);
        }

        let leaderId;
        const [leaderRows] = await connection.execute('SELECT leader_id FROM Leader WHERE email_address = ?', [leader_email]);
        if (leaderRows.length === 0) {
            leaderId = uuidv4();
            console.log(`Leader not found. Creating new leader with ID: ${leaderId} and email: ${leader_email}`);
            await connection.execute('INSERT INTO Leader (leader_id, email_address, track_id) VALUES (?, ?, ?)', [leaderId, leader_email, track_id]);
        } else {
            leaderId = leaderRows[0].leader_id;
            console.log(`Found existing leader with ID: ${leaderId} and email: ${leader_email}`);
        }

        const teamId = `hackhub-2025-team-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
        console.log(`Generated new team ID: ${teamId}`);

        await connection.execute(
            'INSERT INTO Team (team_id, leader_id, problem_id, team_name, problem_selection_id) VALUES (?, ?, ?, ?, ?)',
            [teamId, leaderId, problemIdToInsert, team_name, uuidv4()]
        );
        console.log(`Created new team with ID: ${teamId}, Name: ${team_name}`);

        await connection.commit();
        console.log('Transaction committed successfully.');

        return {
            statusCode: 201,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Team created successfully', teamId: teamId, teamName: team_name }),
        };

    } catch (error) {
        if (connection) {
            try {
                await connection.rollback();
                console.log('Transaction rolled back due to error.');
            } catch (rollbackError) {
                console.error('Error during transaction rollback:', rollbackError);
            }
        }
        console.error('Error creating team:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to create team', error: error.message }),
        };
    } finally {
        // No connection.end() for caching
    }
};