// get-participant-dashboard-data/index.js - MODIFIED to include submission details in teamInfo
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

// Environment variables
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        console.log('Using cached database connection.');
        return cachedConnection;
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        const token = event.headers.Authorization?.split(' ')[1];
        if (!token) {
            return {
                statusCode: 401,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Authorization token missing.' }),
            };
        }

        const userEmail = event.requestContext.authorizer.claims.email;
        const userGroups = event.requestContext.authorizer.claims['cognito:groups'] || [];
        const isParticipant = userGroups.includes('Participants');
        
        if (!isParticipant) {
             return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Forbidden. User is not a participant.' }),
            };
        }

        connection = await connectToDatabase();

        let leaderId = null;
        let teamInfo = null;
        let hasTeamRegistered = false;

        // 1. Check for existing leader and team
        const [leaderRows] = await connection.execute('SELECT leader_id, track_id FROM Leader WHERE email_address = ?', [userEmail]);
        if (leaderRows.length > 0) {
            leaderId = leaderRows[0].leader_id;
            const leaderTrackId = leaderRows[0].track_id;

            const [teamRows] = await connection.execute(`
                SELECT 
                    t.team_id, 
                    t.team_name, 
                    t.problem_id, 
                    ts.submission_video_url,
                    ts.github_url,                   -- NEW
                    ts.submission_project_description, -- NEW
                    ts.submission_additional_materials_url, -- NEW
                    ts.last_updated,                 -- NEW
                    CASE WHEN ts.submission_id IS NOT NULL THEN TRUE ELSE FALSE END as has_submitted,
                    tr.track_title as track_name
                FROM Team t
                LEFT JOIN Team_Submission ts ON t.team_id = ts.team_id
                LEFT JOIN Leader l ON t.leader_id = l.leader_id
                LEFT JOIN Track tr ON l.track_id = tr.track_id
                WHERE t.leader_id = ?
            `, [leaderId]);

            if (teamRows.length > 0) {
                hasTeamRegistered = true;
                const row = teamRows[0];

                // Parse additional materials URL from string to array if it's a JSON string
                let parsedAdditionalUrls = null;
                if (row.submission_additional_materials_url && typeof row.submission_additional_materials_url === 'string') {
                    try { parsedAdditionalUrls = JSON.parse(row.submission_additional_materials_url); }
                    catch (e) { console.error("Lambda: Failed to parse additional materials URL string:", e); parsedAdditionalUrls = []; }
                } else if (Array.isArray(row.submission_additional_materials_url)) {
                     parsedAdditionalUrls = row.submission_additional_materials_url;
                } else {
                     parsedAdditionalUrls = []; // Default to empty array if null/undefined
                }


                teamInfo = {
                    teamId: row.team_id,
                    teamName: row.team_name,
                    problemId: row.problem_id,
                    track: row.track_name?.toLowerCase().includes('student') ? 'student' : 
                           (row.track_name?.toLowerCase().includes('corporate') ? 'corporate' : null),
                    videoUrl: row.submission_video_url,
                    hasSubmitted: row.has_submitted === 1,
                    // NEW: Include submission fields
                    gitlabUrl: row.github_url,
                    submissionProjectDescription: row.submission_project_description,
                    submissionAdditionalMaterialsUrls: parsedAdditionalUrls,
                    lastSubmitted: row.last_updated ? new Date(row.last_updated).toISOString() : null, // Convert to ISO string
                    // END NEW
                };
            }
        }

        // 2. Fetch all tracks for dropdown (still need this for dashboard's team registration section if re-enabled)
        const [tracksRows] = await connection.execute(`
            SELECT
                track_id AS id,
                track_title AS title
            FROM
                Track
            ORDER BY track_title ASC
        `);
        const availableTracks = tracksRows.map(row => ({ id: row.id, title: row.title }));

        return {
            statusCode: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' 
            },
            body: JSON.stringify({
                hasTeamRegistered: hasTeamRegistered,
                teamInfo: teamInfo,
                availableTracks: availableTracks
            }),
        };
    } catch (error) {
        console.error('Error in get-participant-dashboard-data handler:', error);
        return {
            statusCode: 500,
            headers: { 
                'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' 
            },
            body: JSON.stringify({ message: 'Internal server error', error: error.message }),
        };
    } finally {
        if (connection) {
            try {
                await connection.end();
                console.log('Database connection closed.');
            } catch (err) {
                console.error('Failed to close database connection:', err);
            }
        }
    }
};