// get-admin-judges/index.js - NEW Lambda function
const mysql = require("mysql2/promise");
const AWS = require("aws-sdk");
const secretsManager = new AWS.SecretsManager();

// Environment variables for connection info
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || "3306", 10);

let cachedConnection = null;

async function getDbCredentials() {
  console.log("Fetching DB credentials from Secrets Manager...");
  try {
    const data = await secretsManager
      .getSecretValue({ SecretId: DB_SECRET_ARN })
      .promise();
    if ("SecretString" in data) {
      console.log("Successfully fetched secret from Secrets Manager.");
      return JSON.parse(data.SecretString);
    }
    throw new Error("SecretString not found in Secrets Manager response.");
  } catch (err) {
    console.error("Error retrieving secret from Secrets Manager:", err);
    throw err;
  }
}

async function connectToDatabase() {
  console.log("Checking for cached database connection...");
  if (
    cachedConnection &&
    cachedConnection.isValid &&
    cachedConnection.isValid()
  ) {
    console.log("Using cached database connection.");
    return cachedConnection;
  }

  const creds = await getDbCredentials();
  console.log(
    "Connecting to database with host:",
    DB_HOST,
    "user:",
    creds.username,
    "database:",
    DB_DATABASE,
    "port:",
    DB_PORT
  );

  try {
    const connection = await mysql.createConnection({
      host: DB_HOST,
      user: creds.username,
      password: creds.password,
      database: DB_DATABASE,
      port: DB_PORT,
    });
    console.log("Successfully established new database connection.");
    cachedConnection = connection;
    return connection;
  } catch (err) {
    console.error("Error establishing database connection:", err);
    throw err;
  }
}

exports.handler = async (event) => {
  let connection;
  try {
    console.log("Received event:", JSON.stringify(event));
    console.log("Attempting to connect to the database...");

    connection = await connectToDatabase();
    console.log("Database connection obtained (new or cached).");

    console.log("Executing SQL query to fetch judges...");
    const [rows] = await connection.execute(`
            SELECT
                judge_id,
                judge_name,
                email_address
            FROM
                Judge
            ORDER BY judge_name ASC
        `);
    console.log("SQL query executed successfully.");

    const judgesData = rows.map((row) => ({
      judge_id: row.judge_id,
      judge_name: row.judge_name,
      email_address: row.email_address,
    }));

    console.log("Returning successful response with judges data.");
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify(judgesData),
    };
  } catch (error) {
    console.error("Error in handler:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        message: "Internal server error",
        error: error.message,
      }),
    };
  } finally {
    // Connection handling (omit connection.end() for caching)
    if (connection) {
      connection.end();
      console.log("Database connection closed.");
    }
  }
};
