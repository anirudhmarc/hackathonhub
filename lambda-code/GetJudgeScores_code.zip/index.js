const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

// Environment variables must be configured in your Lambda function
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let connectionPool = null;

// Function to get database credentials from AWS Secrets Manager
async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing.");
    }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) {
        return JSON.parse(data.SecretString);
    }
    throw new Error('SecretString not found in Secrets Manager response.');
}

// Function to establish and cache a database connection pool
async function connectToDatabase() {
    if (!connectionPool) {
        const creds = await getDbCredentials();
        connectionPool = mysql.createPool({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Database connection pool created.');
    }
    return connectionPool.getConnection();
}

exports.handler = async (event) => {
    let connection;
    try {
        // Correctly get stage_id from the query string
        const stageId = event.queryStringParameters?.stage_id;
        
        // Ensure stage_id is provided, as it is required for filtering
        if (!stageId) {
             return {
                statusCode: 400,
                headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({ message: "Missing stage_id parameter." }),
            };
        }
        
        connection = await connectToDatabase();
        
        // SQL query to select scores based on stage_id
        const [scores] = await connection.execute(`
            SELECT
                score_id AS id,
                team_id,
                judge_id,
                innovation,
                technical_complexity,
                impact,
                presentation,
                aws_funding_vote,
                feedback,
                strength,
                improvement,
                last_updated,
                stage_id
            FROM Score
            WHERE stage_id = ?
        `, [stageId]);
        
        return {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify(scores),
        };
    } catch (error) {
        console.error("Database query failed:", error);
        return {
            statusCode: 500,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({ message: "Internal Server Error", error: error.message }),
        };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};