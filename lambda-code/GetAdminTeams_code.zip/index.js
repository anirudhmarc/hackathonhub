// get-admin-teams/index.js - FINAL WITH FINALIST STATUS
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

// Environment variables for connection info
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    console.log('Fetching DB credentials from Secrets Manager...');
    try {
        const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
        if ('SecretString' in data) {
            console.log('Successfully fetched secret from Secrets Manager.');
            return JSON.parse(data.SecretString);
        }
        throw new Error('SecretString not found in Secrets Manager response.');
    } catch (err) {
        console.error('Error retrieving secret from Secrets Manager:', err);
        throw err;
    }
}

async function connectToDatabase() {
    console.log('Checking for cached database connection...');
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        console.log('Using cached database connection.');
        return cachedConnection;
    }

    const creds = await getDbCredentials();
    console.log("Connecting to database with host:", DB_HOST, "user:", creds.username, "database:", DB_DATABASE, "port:", DB_PORT);

    try {
        const connection = await mysql.createConnection({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT
        });
        console.log('Successfully established new database connection.');
        cachedConnection = connection;
        return connection;
    } catch (err) {
        console.error('Error establishing database connection:', err);
        throw err;
    }
}

exports.handler = async (event) => {
    let connection;
    try {
        console.log('Received event:', JSON.stringify(event));
        console.log('Attempting to connect to the database...');

        connection = await connectToDatabase();
        console.log('Database connection obtained (new or cached).');

        console.log('Executing SQL query to fetch teams...');
        const [teamsRows] = await connection.execute(`
            SELECT
                t.team_id AS id,
                t.team_name AS name,
                l.email_address AS leader_email,
                ps.problem_id,
                ps.problem_title,
                ps.problem_description,
                tr.track_title AS track_name_from_db,
                tr.track_id AS track_id_from_db,
                (ts.submission_id IS NOT NULL) AS has_submitted_from_db,
                t.is_finalist
            FROM
                Team t
            LEFT JOIN
                Leader l ON t.leader_id = l.leader_id
            LEFT JOIN
                Problem_Statement ps ON t.problem_id = ps.problem_id
            LEFT JOIN
                Track tr ON l.track_id = tr.track_id
            LEFT JOIN
                Team_Submission ts ON t.team_id = ts.team_id
        `);
        console.log('SQL query for teams executed successfully.');

        const teamsData = teamsRows.map(row => ({
            id: row.id,
            name: row.name,
            leader_email: row.leader_email,
            problem_id: row.problem_id,
            problem_title: row.problem_title,
            problem_description: row.problem_description,
            track: (row.track_name_from_db === null || row.track_name_from_db === '')
                        ? 'corporate'
                        : (row.track_name_from_db.toLowerCase().includes('student') ? 'student' : 'corporate'),
            track_id: row.track_id_from_db,
            has_submitted: !!row.has_submitted_from_db,
            is_finalist: !!row.is_finalist
        }));
        
        console.log('Executing SQL query to fetch problem statements with slot count...');
        const [problemsRows] = await connection.execute(`
            SELECT
                ps.problem_id AS id,
                ps.problem_title AS title,
                ps.problem_max_slots AS max_slots,
                ps.track_id,
                COUNT(t.team_id) AS current_slots
            FROM
                Problem_Statement ps
            LEFT JOIN
                Team t ON ps.problem_id = t.problem_id
            GROUP BY
                ps.problem_id, ps.problem_title, ps.problem_max_slots, ps.track_id
            ORDER BY ps.problem_title ASC
        `);
        console.log('SQL query for problems executed successfully.');

        const problemsData = problemsRows.map(row => ({
            id: row.id,
            title: row.title,
            trackId: row.track_id,
            maxSlots: row.max_slots,
            currentSlots: row.current_slots,
            isAvailable: row.current_slots < row.max_slots
        }));

        console.log('Executing SQL query to fetch tracks...');
        const [tracksRows] = await connection.execute(`
            SELECT
                track_id AS id,
                track_title AS title
            FROM
                Track
            ORDER BY track_title ASC
        `);
        console.log('SQL query for tracks executed successfully.');

        const tracksData = tracksRows.map(row => ({
            id: row.id,
            title: row.title
        }));

        console.log('Returning successful response with all data.');
        return {
            statusCode: 200,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' 
            },
            body: JSON.stringify({ teams: teamsData, problems: problemsData, tracks: tracksData }),
        };
    } catch (error) {
        console.error('Error in handler:', error);
        return {
            statusCode: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' 
            },
            body: JSON.stringify({ message: 'Internal server error', error: error.message }),
        };
    } finally {
    }
};