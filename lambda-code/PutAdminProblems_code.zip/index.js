// put-admin-problems/index.js - MODIFIED
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const { v4: uuidv4 } = require('uuid');

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing from environment variables.");
    }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) {
        return JSON.parse(data.SecretString);
    }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.connection) {
        try {
            await cachedConnection.ping();
            return cachedConnection;
        } catch (pingError) {
            console.warn('Cached connection is stale. Reconnecting.', pingError.message);
            try { if (cachedConnection.connection) await cachedConnection.connection.end(); } catch (e) { console.error('Error closing stale connection:', e); }
            cachedConnection = null;
        }
    }

    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({
        host: DB_HOST,
        user: creds.username,
        password: creds.password,
        database: DB_DATABASE,
        port: DB_PORT
    });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        console.log('Received event:', JSON.stringify(event));

        const problemId = event.pathParameters?.problemId;
        if (!problemId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing problemId in path parameters.' }),
            };
        }

        const body = JSON.parse(event.body);

        // Perbaikan: Ubah nama variabel menjadi snake_case agar sesuai dengan frontend
        const { problem_title, problem_description, problem_tag, problem_max_slots, track_id } = body;

        if (!problem_title || !problem_description || !problem_max_slots || !track_id) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing required fields: problem_title, problem_description, problem_max_slots, track_id.' }),
            };
        }

        connection = await connectToDatabase();
        const [result] = await connection.execute(
            'UPDATE Problem_Statement SET problem_title = ?, problem_description = ?, problem_tag = ?, problem_max_slots = ?, track_id = ? WHERE problem_id = ?',
            [problem_title, problem_description, problem_tag, problem_max_slots, track_id, problemId]
        );

        if (result.affectedRows === 0) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Problem not found or no changes made.' }),
            };
        }

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Problem updated successfully', problemId: problemId }),
        };
    } catch (error) {
        console.error('Error updating problem:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to update problem', error: error.message }),
        };
    }
};