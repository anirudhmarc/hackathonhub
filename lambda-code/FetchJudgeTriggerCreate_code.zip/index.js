import { LambdaClient, InvokeCommand } from '@aws-sdk/client-lambda';
import mysql from 'mysql2/promise';

const lambdaClient = new LambdaClient({ region: 'ap-southeast-5' });
const CREATE_USER_LAMBDA_NAME = 'create-cognito-user'; // or full ARN

async function getDatabaseConnection() {
  return mysql.createConnection({
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
    connectTimeout: 10000,
    // ⚠️ Remove invalid 'timeout' option — causes warning!
  });
}

export const handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  const judgeId = event.pathParameters.judgeId;

  let body;
  try {
    body = JSON.parse(event.body);
  } catch (error) {
    console.error('Failed to parse request body:', error);
    return {
      statusCode: 400,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ message: 'Invalid JSON in request body' })
    };
  }

  const { default_password } = body;
  if (!default_password) {
    return {
      statusCode: 400,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ message: 'default_password is required' })
    };
  }

  let connection;
  try {
    connection = await getDatabaseConnection();
    
    const [rows] = await connection.execute(
      'SELECT email_address, judge_name FROM judges WHERE judge_id = ?',
      [judgeId]
    );
    
    if (rows.length === 0) {
      return {
        statusCode: 404,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ message: 'Judge not found in database.' })
      };
    }
    
    const { email_address: judgeEmail, judge_name: judgeName } = rows[0];
    console.log(`Found judge: ${judgeName} with email: ${judgeEmail}`);

    // 👇 INVOKE SECOND LAMBDA
    const payload = {
      judgeEmail,
      judgeName,
      default_password
    };

    const command = new InvokeCommand({
      FunctionName: CREATE_USER_LAMBDA_NAME,
      InvocationType: 'RequestResponse', // Change to 'Event' for async/fire-and-forget
      Payload: Buffer.from(JSON.stringify(payload))
    });

    const response = await lambdaClient.send(command);

    // Parse response from Lambda 2
    const result = JSON.parse(Buffer.from(response.Payload).toString());

    return {
      statusCode: result.statusCode || 200,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify(result.body ? JSON.parse(result.body) : result)
    };

  } catch (error) {
    console.error('Error in Lambda 1:', error);
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({
        message: 'Failed to process request.',
        details: error.message
      })
    };
  } finally {
    if (connection) await connection.end();
  }
};