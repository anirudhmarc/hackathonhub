// put-admin-teams/index.js - MODIFIED FOR FINALIST STATUS
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const { v4: uuidv4 } = require('uuid');

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing from environment variables.");
    }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) {
        return JSON.parse(data.SecretString);
    }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.connection) {
        try {
            await cachedConnection.ping();
            return cachedConnection;
        } catch (pingError) {
            console.warn('Cached connection is stale. Reconnecting.', pingError.message);
            try { if (cachedConnection.connection) await cachedConnection.connection.end(); } catch (e) { console.error('Error closing stale connection:', e); }
            cachedConnection = null;
        }
    }

    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({
        host: DB_HOST,
        user: creds.username,
        password: creds.password,
        database: DB_DATABASE,
        port: DB_PORT
    });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        console.log('Received event:', JSON.stringify(event));

        const teamId = event.pathParameters?.teamId;
        if (!teamId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing teamId in path parameters.' }),
            };
        }

        const body = JSON.parse(event.body);

        const { team_name, leader_email, problem_id, track_id, has_submitted, is_finalist } = body;

        if (!team_name || !leader_email || !track_id) {
            // Check for required fields for a full update, but allow a partial update for is_finalist
            if (is_finalist === undefined) {
                return {
                    statusCode: 400,
                    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                    body: JSON.stringify({ message: 'Missing required fields: team_name, leader_email, track_id.' }),
                };
            }
        }

        connection = await connectToDatabase();
        await connection.beginTransaction();

        // Handle full team update logic
        if (team_name && leader_email && track_id) {
            const [trackRows] = await connection.execute('SELECT track_id FROM Track WHERE track_id = ?', [track_id]);
            if (trackRows.length === 0) {
                await connection.rollback();
                return { statusCode: 400, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ message: `Invalid track_id: ${track_id}. Track not found.` }) };
            }

            if (problem_id) {
                console.log(`Checking slots for problem_id: ${problem_id}`);
                const [problemInfoRows] = await connection.execute(
                    `SELECT problem_title, problem_max_slots FROM Problem_Statement WHERE problem_id = ?`,
                    [problem_id]
                );

                if (problemInfoRows.length === 0) {
                    await connection.rollback();
                    return {
                        statusCode: 400,
                        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                        body: JSON.stringify({ message: `Problem with ID ${problem_id} not found.` }),
                    };
                }

                const problemInfo = problemInfoRows[0];
                const [currentSlotsRows] = await connection.execute(
                    `SELECT COUNT(*) AS current_teams FROM Team WHERE problem_id = ? AND team_id != ?`,
                    [problem_id, teamId]
                );
                const currentTeams = currentSlotsRows[0].current_teams;

                if (currentTeams >= problemInfo.problem_max_slots) {
                    await connection.rollback();
                    return {
                        statusCode: 400,
                        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                        body: JSON.stringify({ message: `The problem "${problemInfo.problem_title}" is full. Max slots: ${problemInfo.problem_max_slots}.` }),
                    };
                }
                console.log(`Problem "${problemInfo.problem_title}" has ${currentTeams}/${problemInfo.problem_max_slots} slots filled.`);
            }

            let leaderId;
            const [leaderRows] = await connection.execute('SELECT leader_id FROM Leader WHERE email_address = ?', [leader_email]);
            if (leaderRows.length === 0) {
                leaderId = uuidv4();
                await connection.execute('INSERT INTO Leader (leader_id, email_address, track_id) VALUES (?, ?, ?)', [leaderId, leader_email, track_id]);
                console.log(`Created new leader with ID: ${leaderId}`);
            } else {
                leaderId = leaderRows[0].leader_id;
                await connection.execute('UPDATE Leader SET track_id = ? WHERE leader_id = ?', [track_id, leaderId]);
                console.log(`Updated existing leader trackId for ID: ${leaderId}`);
            }

            await connection.execute(
                `UPDATE Team SET
                    leader_id = ?,
                    problem_id = ?,
                    team_name = ?
                WHERE team_id = ?`,
                [leaderId, problem_id || null, team_name, teamId]
            );

            if (has_submitted !== undefined) {
                if (has_submitted === true) {
                    const [subExists] = await connection.execute('SELECT submission_id FROM Team_Submission WHERE team_id = ?', [teamId]);
                    if (subExists.length === 0) {
                        await connection.execute(
                            `INSERT INTO Team_Submission (submission_id, team_id, last_updated, submission_video_url, github_url, submission_project_description)
                            VALUES (?, ?, NOW(), ?, ?, ?)`,
                            [uuidv4(), teamId, 'placeholder_url', 'placeholder_github', 'Admin-set submitted status']
                        );
                        console.log(`Created placeholder submission for team ${teamId}.`);
                    } else {
                        console.log(`Submission already exists for team ${teamId}.`);
                    }
                } else if (has_submitted === false) {
                    const [deleteResult] = await connection.execute('DELETE FROM Team_Submission WHERE team_id = ?', [teamId]);
                    if (deleteResult.affectedRows > 0) {
                        console.log(`Deleted submission(s) for team ${teamId}.`);
                    } else {
                        console.log(`No submission found to delete for team ${teamId}.`);
                    }
                }
            }
        }
        
        // Handle standalone finalist update
        if (is_finalist !== undefined) {
            console.log(`Updating finalist status for team ${teamId} to ${is_finalist}`);
            const [updateFinalistResult] = await connection.execute(
                `UPDATE Team SET is_finalist = ? WHERE team_id = ?`,
                [is_finalist, teamId]
            );
            console.log(`Finalist status updated, affected rows: ${updateFinalistResult.affectedRows}`);
        }

        await connection.commit();

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Team updated successfully', teamId: teamId }),
        };

    } catch (error) {
        if (connection) {
            try {
                await connection.rollback();
                console.log('Transaction rolled back due to error.');
            } catch (rollbackError) {
                console.error('Error during transaction rollback:', rollbackError);
            }
        }
        console.error('Error updating team:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to update team', error: error.message }),
        };
    } finally {
    }
};