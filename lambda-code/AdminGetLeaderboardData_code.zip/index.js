const mysql = require('mysql2/promise');

// Database connection configuration
const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: parseInt(process.env.DB_PORT || '3306'),
  connectTimeout: 10000,
  charset: 'utf8mb4'
};

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  let connection;
  
  try {
    // Create database connection
    connection = await mysql.createConnection(dbConfig);
    console.log('Database connected successfully');

    // Support optional query parameters: judge_id, stage_id, team_id
    const qs = event.queryStringParameters || {};
    const filterJudgeId = qs.judge_id || null;
    const filterStageId = qs.stage_id || null;
    const filterTeamId = qs.team_id || null;

    // Fetch teams with track info
    const teamQuery = `
      SELECT
        t.team_id AS id,
        t.team_name AS name,
        t.problem_id AS problem_id,
        ps.problem_title AS problem_title,
        COALESCE(tr.track_title, leader_tr.track_title) AS track_name,
        t.is_finalist,
        t.top20_student,
        t.top10_corporate,
        t.image_url
      FROM Team t
      LEFT JOIN Problem_Statement ps ON t.problem_id = ps.problem_id
      LEFT JOIN Track tr ON ps.track_id = tr.track_id
      LEFT JOIN Leader l ON t.leader_id = l.leader_id
      LEFT JOIN Track leader_tr ON l.track_id = leader_tr.track_id
    `;
    
    const [teams] = await connection.execute(teamQuery);
    console.log(`Fetched ${teams.length} teams`);

    // Fetch problems
    const problemQuery = `
      SELECT
        problem_id AS id,
        problem_title AS title
      FROM Problem_Statement
    `;
    
    const [problems] = await connection.execute(problemQuery);
    console.log(`Fetched ${problems.length} problems`);

    // Fetch scores with optional filtering
    let scoresQuery = `
      SELECT
        s.score_id AS id,
        s.team_id,
        s.judge_id,
        j.judge_name AS judge_name,
        s.innovation,
        s.technical_complexity,
        s.impact,
        s.presentation,
        s.aws_funding_vote,
        s.feedback,
        s.strength,
        s.improvement,
        s.last_updated,
        s.stage_id
      FROM Score s
      LEFT JOIN Judge j ON s.judge_id = j.judge_id
    `;
    
    const whereClauses = [];
    const params = [];
    
    if (filterJudgeId) {
      whereClauses.push('s.judge_id = ?');
      params.push(filterJudgeId);
    }
    if (filterStageId) {
      whereClauses.push('s.stage_id = ?');
      params.push(filterStageId);
    }
    if (filterTeamId) {
      whereClauses.push('s.team_id = ?');
      params.push(filterTeamId);
    }
    
    if (whereClauses.length > 0) {
      scoresQuery += ' WHERE ' + whereClauses.join(' AND ');
    }
    
    const [scores] = await connection.execute(scoresQuery, params);
    console.log(`Fetched ${scores.length} scores`);

    // Fetch judging stages
    const stagesQuery = `
      SELECT
        stage_id,
        stage_name
      FROM Judging_Stage
      ORDER BY start_time ASC
    `;
    
    const [judgingStages] = await connection.execute(stagesQuery);
    console.log(`Fetched ${judgingStages.length} judging stages`);

    // Fetch judges list
    const judgesQuery = `
      SELECT
        judge_id,
        judge_name,
        email_address
      FROM Judge
    `;
    
    const [judges] = await connection.execute(judgesQuery);
    console.log(`Fetched ${judges.length} judges`);

    // Close connection
    await connection.end();

    // Return response
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,OPTIONS'
      },
      body: JSON.stringify({
        teams: teams || [],
        problems: problems || [],
        scores: scores || [],
        judgingStages: judgingStages || [],
        judges: judges || []
      })
    };

  } catch (error) {
    console.error('Error:', error);
    
    // Close connection if open
    if (connection) {
      try {
        await connection.end();
      } catch (closeError) {
        console.error('Error closing connection:', closeError);
      }
    }

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        message: 'Internal Server Error',
        error: error.message
      })
    };
  }
};
