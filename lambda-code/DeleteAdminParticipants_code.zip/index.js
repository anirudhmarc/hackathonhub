// delete-admin-participants/index.js - FIXED CORS

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, DeleteCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({ region: process.env.REGION || "ap-southeast-2" });
const docClient = DynamoDBDocumentClient.from(client);

const PARTICIPANTS_TABLE_NAME = process.env.DYNAMODB_TABLE_NAME || process.env.TABLE_NAME || 'HackathonRegistrations';

export const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event));

    const responseHeaders = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*", // Allow all origins
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "DELETE,OPTIONS",
    };

    if (event.requestContext?.http?.method === "OPTIONS" || event.httpMethod === "OPTIONS") {
        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify({ message: "CORS preflight passed" }),
        };
    }

    try {
        const participantId = event.pathParameters?.id || event.pathParameters?.participantId;

        if (!participantId) {
            return {
                statusCode: 400,
                headers: responseHeaders,
                body: JSON.stringify({ message: 'Participant ID is required.' }),
            };
        }

        const params = {
            TableName: PARTICIPANTS_TABLE_NAME,
            Key: {
                participant_id: participantId,
            },
        };

        console.log('Deleting participant:', participantId);
        await docClient.send(new DeleteCommand(params));
        console.log('Participant deleted successfully');

        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify({ message: 'Participant deleted successfully' }),
        };

    } catch (error) {
        console.error('Error deleting participant:', error);
        return {
            statusCode: 500,
            headers: responseHeaders,
            body: JSON.stringify({ message: 'Failed to delete participant', error: error.message }),
        };
    }
};
