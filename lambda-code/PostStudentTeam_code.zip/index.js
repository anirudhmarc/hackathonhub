// index.js (Lambda for participant team registration) - REVISED to generate teamId
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const { v4: uuidv4 } = require('uuid'); // Keep uuidv4 for leaderId if needed

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.connection) {
        try { await cachedConnection.ping(); return cachedConnection; } catch (e) {
            console.warn('Cached connection is stale. Reconnecting.');
            cachedConnection = null;
        }
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

exports.handler = async (event) => {
    let connection;
    try {
        const token = event.headers.Authorization?.split(' ')[1];
        if (!token) {
            return {
                statusCode: 401,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Authorization token missing.' }),
            };
        }

        const body = JSON.parse(event.body);
        const { teamName } = body; // --- NEW: Only destructure teamName from body ---
        const userEmail = event.requestContext.authorizer.claims.email;
        const userGroups = event.requestContext.authorizer.claims['cognito:groups'] || [];
        const isParticipant = userGroups.includes('Participants');
        
        if (!isParticipant) {
             return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Forbidden. User is not a participant.' }),
            };
        }

        // Validate teamName
        if (!teamName) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing required field: teamName.' }),
            };
        }

        connection = await connectToDatabase();
        await connection.beginTransaction();

        const [existingLeader] = await connection.execute('SELECT leader_id FROM Leader WHERE email_address = ?', [userEmail]);
        
        // Check if leader already has a team
        if (existingLeader.length > 0) {
            const [existingTeamForLeader] = await connection.execute('SELECT team_name FROM Team WHERE leader_id = ?', [existingLeader[0].leader_id]);
            if (existingTeamForLeader.length > 0) {
                await connection.rollback();
                return {
                    statusCode: 409, // Conflict
                    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                    body: JSON.stringify({ message: 'You have already registered a team.' }),
                };
            }
        }

        const leaderId = existingLeader.length > 0 ? existingLeader[0].leader_id : uuidv4(); // Generate leaderId if new
        
        // --- NEW: Generate teamId in the desired format within the Lambda ---
        const teamId = `hackhub-2025-team-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`; // Pad with leading zeros
        
        // --- NEW: Define a default track_id (must exist in your Track table) ---
        const defaultTrackId = "72101be3-6921-11f0-b168-0efd9d2909e1"; // Replace with YOUR ACTUAL STUDENT TRACK ID

        if (existingLeader.length === 0) {
            // Use the defaultTrackId for Leader insertion if leader is new
            await connection.execute('INSERT INTO Leader (leader_id, email_address, track_id) VALUES (?, ?, ?)', [leaderId, userEmail, defaultTrackId]);
        }

        // Use the newly generated teamId for Team insertion
        await connection.execute('INSERT INTO Team (team_id, leader_id, team_name) VALUES (?, ?, ?)', [teamId, leaderId, teamName]);

        await connection.commit();

        return {
            statusCode: 201,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Team created successfully', teamId: teamId, teamName: teamName }),
        };
    } catch (error) {
        if (connection) { await connection.rollback(); }
        console.error('Error creating team:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to create team', error: error.message }),
        };
    }
};