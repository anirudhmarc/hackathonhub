// get-participants/index.js - FIXED VERSION

import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, ScanCommand } from '@aws-sdk/lib-dynamodb';

const REGION = process.env.AWS_REGION || "ap-southeast-1";
const TABLE_NAME = process.env.DYNAMODB_TABLE_NAME || "HackathonRegistrations";
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || "http://localhost:8080";

const ddbClient = new DynamoDBClient({ region: REGION });
const docClient = DynamoDBDocumentClient.from(ddbClient);

export const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event));

    const responseHeaders = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*', // Allow all origins for now
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
    };

    if (event.requestContext?.http?.method === "OPTIONS") {
        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify({ message: "CORS preflight passed" }),
        };
    }

    try {
        const params = { TableName: TABLE_NAME };
        const data = await docClient.send(new ScanCommand(params));

        const participants = data.Items.map(item => {
            // Parse leader field
            let leaderData = item.leader;
            if (typeof leaderData === 'string' && leaderData.trim() !== '') {
                try {
                    leaderData = JSON.parse(leaderData);
                } catch (e) {
                    console.warn(`Error parsing leader for ${item.participant_id}:`, e);
                    leaderData = null;
                }
            }
            leaderData = (leaderData && typeof leaderData === 'object') ? leaderData : null;

            // Parse members field
            let membersData = item.members;
            if (typeof membersData === 'string' && membersData.trim() !== '') {
                try {
                    membersData = JSON.parse(membersData);
                } catch (e) {
                    console.warn(`Error parsing members for ${item.participant_id}:`, e);
                    membersData = [];
                }
            }
            membersData = Array.isArray(membersData) ? membersData : [];

            // Parse emails field - THIS IS THE FIX
            let emailsData = item.emails;
            if (typeof emailsData === 'string' && emailsData.trim() !== '') {
                try {
                    emailsData = JSON.parse(emailsData);
                } catch (e) {
                    console.warn(`Error parsing emails for ${item.participant_id}:`, e);
                    emailsData = [];
                }
            }
            emailsData = Array.isArray(emailsData) ? emailsData : [];

            return {
                id: item.participant_id,
                participant_id: item.participant_id,
                agreeEmailCommunications: item.agreeEmailCommunications || false,
                agreeMarketingEmails: item.agreeMarketingEmails || false,
                agreeTermsConditions: item.agreeTermsConditions || false,
                emails: emailsData, // Now properly parsed as array
                leader: leaderData,
                memberCount: item.memberCount || 0,
                members: membersData,
                status: item.status || 'PENDING_APPROVAL',
                submittedAt: item.submittedAt || new Date().toISOString(),
                teamName: item.teamName || '',
                track: item.track || '',
            };
        });

        return {
            statusCode: 200,
            headers: responseHeaders,
            body: JSON.stringify(participants),
        };
    } catch (error) {
        console.error('Error fetching participants:', error);
        return {
            statusCode: 500,
            headers: responseHeaders,
            body: JSON.stringify({
                message: 'Internal Server Error',
                error: error.message
            }),
        };
    }
};
