// index.js - AWS Lambda Function (Fixed Version for Participant Feedback)

const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

// Environment variables
const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) {
        throw new Error("Database secret ARN is missing.");
    }
    try {
        const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
        if ('SecretString' in data) {
            return JSON.parse(data.SecretString);
        }
        throw new Error('SecretString not found in Secrets Manager response.');
    } catch (error) {
        console.error("Error fetching database credentials from Secrets Manager:", error);
        throw new Error("Failed to retrieve database credentials.");
    }
}

async function connectToDatabase() {
    if (cachedConnection) {
        try {
            await cachedConnection.ping();
            return cachedConnection;
        } catch (e) {
            console.warn('Cached connection is stale or lost. Reconnecting.');
            cachedConnection = null;
        }
    }

    try {
        const creds = await getDbCredentials();
        const connection = await mysql.createConnection({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT,
            waitForConnections: true,
            connectionLimit: 10
        });
        cachedConnection = connection;
        console.log("Successfully connected to the database.");
        return connection;
    } catch (error) {
        console.error("Failed to connect to the database:", error);
        throw new Error("Database connection failed.");
    }
}

exports.handler = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;
    
    console.log("Received event:", JSON.stringify(event, null, 2));

    let connection;
    try {
        const userEmail = event.requestContext?.authorizer?.claims?.email;

        if (!userEmail) {
            return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Forbidden. User email is missing from token claims.' }),
            };
        }

        connection = await connectToDatabase();

        // Step 1: Find teamId from user email
        const [leaderRows] = await connection.execute(
            `SELECT leader_id FROM Leader WHERE email_address = ?`, 
            [userEmail]
        );

        if (leaderRows.length === 0) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Leader not found. Please register a team first.' }),
            };
        }

        const leaderId = leaderRows[0].leader_id;
        const [teamRows] = await connection.execute(
            `SELECT team_id FROM Team WHERE leader_id = ?`, 
            [leaderId]
        );
        
        if (teamRows.length === 0) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Team not found. User has not created a team.' }),
            };
        }
        
        const teamId = teamRows[0].team_id;

        // Step 2: Get feedback with all required fields
        const [rows] = await connection.execute(
            `SELECT 
                s.score_id, 
                s.judge_id, 
                j.judge_name,
                s.innovation, 
                s.technical_complexity, 
                s.impact, 
                s.presentation,
                s.feedback,
                s.strength,
                s.improvement,
                s.aws_funding_vote,
                s.last_updated
            FROM Score s
            JOIN Judge j ON s.judge_id = j.judge_id
            WHERE s.team_id = ?`,
            [teamId]
        );

        const formattedFeedback = rows.map(row => {
            let strengths = [];
            try {
                if (row.strength) {
                    strengths = JSON.parse(row.strength);
                    if (!Array.isArray(strengths)) {
                        strengths = [row.strength];
                    }
                }
            } catch (e) {
                console.warn("Could not parse strengths as JSON, treating as plain text:", row.strength);
                strengths = row.strength ? [row.strength] : [];
            }

            let improvements = [];
            try {
                if (row.improvement) {
                    improvements = JSON.parse(row.improvement);
                    if (!Array.isArray(improvements)) {
                        improvements = [row.improvement];
                    }
                }
            } catch (e) {
                console.warn("Could not parse improvements as JSON, treating as plain text:", row.improvement);
                improvements = row.improvement ? [row.improvement] : [];
            }

            return {
                id: row.score_id,
                judge: row.judge_name || 'Anonymous Judge',
                role: 'Judge',
                date: row.last_updated ? new Date(row.last_updated).toISOString() : new Date().toISOString(),
                scores: {
                    innovation: row.innovation || 0,
                    execution: row.technical_complexity || 0,
                    impact: row.impact || 0,
                    presentation: row.presentation || 0,
                    technical: row.technical_complexity || 0
                },
                comments: row.feedback || '',
                strengths: strengths,
                improvements: improvements,
                aws_funding_vote: row.aws_funding_vote || null
            };
        });

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ feedback: formattedFeedback }),
        };

    } catch (error) {
        console.error("Error in Lambda handler:", error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to retrieve feedback.', error: error.message }),
        };
    } finally {
        if (connection) {
            try {
                await connection.end();
                console.log('Database connection closed.');
            } catch (err) {
                console.error('Failed to close database connection:', err);
            }
        }
    }
};
