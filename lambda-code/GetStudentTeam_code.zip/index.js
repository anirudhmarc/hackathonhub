// get-participant-dashboard-data/index.js - includes submission details with presigned URLs
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const s3 = new AWS.S3({ region: process.env.REGION || 'ap-southeast-2' });

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);
const S3_BUCKET_NAME = process.env.S3_BUCKET_NAME;

let cachedConnection = null;

async function getDbCredentials() {
    if (!DB_SECRET_ARN) { throw new Error("Database secret ARN is missing."); }
    const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
    if ('SecretString' in data) { return JSON.parse(data.SecretString); }
    throw new Error('SecretString not found in Secrets Manager response.');
}

async function connectToDatabase() {
    if (cachedConnection && cachedConnection.isValid && cachedConnection.isValid()) {
        return cachedConnection;
    }
    const creds = await getDbCredentials();
    const connection = await mysql.createConnection({ host: DB_HOST, user: creds.username, password: creds.password, database: DB_DATABASE, port: DB_PORT });
    cachedConnection = connection;
    return connection;
}

async function getPresignedUrl(s3UrlOrKey) {
    if (!s3UrlOrKey || !S3_BUCKET_NAME) return s3UrlOrKey;

    let s3Key = s3UrlOrKey;
    if (s3UrlOrKey.startsWith('https://')) {
        try {
            const url = new URL(s3UrlOrKey);
            s3Key = url.pathname.startsWith('/') ? url.pathname.slice(1) : url.pathname;
        } catch (e) { /* use as-is */ }
    }

    try {
        return await s3.getSignedUrlPromise('getObject', {
            Bucket: S3_BUCKET_NAME,
            Key: s3Key,
            Expires: 3600,
        });
    } catch (error) {
        console.error('Failed to generate presigned URL for:', s3Key, error.message);
        return s3UrlOrKey;
    }
}

exports.handler = async (event) => {
    let connection;
    try {
        const token = event.headers.Authorization?.split(' ')[1];
        if (!token) {
            return {
                statusCode: 401,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Authorization token missing.' }),
            };
        }

        const userEmail = event.requestContext.authorizer.claims.email;
        const userGroups = event.requestContext.authorizer.claims['cognito:groups'] || [];
        const isParticipant = userGroups.includes('Participants');

        if (!isParticipant) {
             return {
                statusCode: 403,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Forbidden. User is not a participant.' }),
            };
        }

        connection = await connectToDatabase();

        let leaderId = null;
        let teamInfo = null;
        let hasTeamRegistered = false;

        const [leaderRows] = await connection.execute('SELECT leader_id, track_id FROM Leader WHERE email_address = ?', [userEmail]);
        if (leaderRows.length > 0) {
            leaderId = leaderRows[0].leader_id;

            const [teamRows] = await connection.execute(`
                SELECT
                    t.team_id,
                    t.team_name,
                    t.problem_id,
                    ts.submission_video_url,
                    ts.github_url,
                    ts.submission_project_description,
                    ts.submission_additional_materials_url,
                    ts.last_updated,
                    CASE WHEN ts.submission_id IS NOT NULL THEN TRUE ELSE FALSE END as has_submitted,
                    tr.track_title as track_name
                FROM Team t
                LEFT JOIN Team_Submission ts ON t.team_id = ts.team_id
                LEFT JOIN Leader l ON t.leader_id = l.leader_id
                LEFT JOIN Track tr ON l.track_id = tr.track_id
                WHERE t.leader_id = ?
            `, [leaderId]);

            if (teamRows.length > 0) {
                hasTeamRegistered = true;
                const row = teamRows[0];

                // Generate presigned URL for video
                const presignedVideoUrl = await getPresignedUrl(row.submission_video_url);

                // Parse and presign additional materials URLs
                let parsedAdditionalUrls = [];
                if (row.submission_additional_materials_url && typeof row.submission_additional_materials_url === 'string') {
                    try {
                        const urls = JSON.parse(row.submission_additional_materials_url);
                        if (Array.isArray(urls)) {
                            parsedAdditionalUrls = await Promise.all(urls.map(url => getPresignedUrl(url)));
                        }
                    } catch (e) {
                        // Single URL, not JSON array
                        const presigned = await getPresignedUrl(row.submission_additional_materials_url);
                        parsedAdditionalUrls = [presigned];
                    }
                } else if (Array.isArray(row.submission_additional_materials_url)) {
                    parsedAdditionalUrls = await Promise.all(
                        row.submission_additional_materials_url.map(url => getPresignedUrl(url))
                    );
                }

                teamInfo = {
                    teamId: row.team_id,
                    teamName: row.team_name,
                    problemId: row.problem_id,
                    track: row.track_name?.toLowerCase().includes('student') ? 'student' :
                           (row.track_name?.toLowerCase().includes('corporate') ? 'corporate' : null),
                    videoUrl: presignedVideoUrl,
                    hasSubmitted: row.has_submitted === 1,
                    gitlabUrl: row.github_url,
                    submissionProjectDescription: row.submission_project_description,
                    submissionAdditionalMaterialsUrls: parsedAdditionalUrls,
                    lastSubmitted: row.last_updated ? new Date(row.last_updated).toISOString() : null,
                };
            }
        }

        const [tracksRows] = await connection.execute(`
            SELECT track_id AS id, track_title AS title FROM Track ORDER BY track_title ASC
        `);
        const availableTracks = tracksRows.map(row => ({ id: row.id, title: row.title }));

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({
                hasTeamRegistered: hasTeamRegistered,
                teamInfo: teamInfo,
                availableTracks: availableTracks
            }),
        };
    } catch (error) {
        console.error('Error in get-participant-dashboard-data handler:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Internal server error', error: error.message }),
        };
    } finally {
        if (connection) {
            try { await connection.end(); } catch (err) { console.error('Failed to close connection:', err); }
        }
    }
};
