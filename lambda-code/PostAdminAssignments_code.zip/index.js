const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();
const { v4: uuidv4 } = require('uuid');

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_DATABASE = process.env.DB_DATABASE;
const DB_PORT = parseInt(process.env.DB_PORT || '3306', 10);

let connectionPool = null;

async function getDbCredentials() {
    console.log('Fetching DB credentials from Secrets Manager...');
    try {
        const data = await secretsManager.getSecretValue({ SecretId: DB_SECRET_ARN }).promise();
        if ('SecretString' in data) {
            console.log('Successfully fetched secret from Secrets Manager.');
            return JSON.parse(data.SecretString);
        }
        throw new Error('SecretString not found in Secrets Manager response.');
    } catch (err) {
        console.error('Error retrieving secret from Secrets Manager:', err);
        throw err;
    }
}

// FIX: Change to use a connection pool instead of a single connection
async function connectToDatabase() {
    if (!connectionPool) {
        const creds = await getDbCredentials();
        connectionPool = mysql.createPool({
            host: DB_HOST,
            user: creds.username,
            password: creds.password,
            database: DB_DATABASE,
            port: DB_PORT,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0
        });
        console.log('Database connection pool created.');
    }
    return connectionPool.getConnection();
}

exports.handler = async (event) => {
    let connection;
    try {
        const body = JSON.parse(event.body);
        const { judgeId, teamId, stageId } = body;

        if (!judgeId || !teamId || !stageId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Missing required fields: judgeId, teamId, or stageId.' }),
            };
        }

        // FIX: Get a connection from the pool
        connection = await connectToDatabase();
        await connection.beginTransaction();

        const [judgeExists] = await connection.execute('SELECT judge_id FROM Judge WHERE judge_id = ?', [judgeId]);
        if (judgeExists.length === 0) {
            await connection.rollback();
            return { statusCode: 400, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ message: 'Judge not found.' }) };
        }
        const [teamExists] = await connection.execute('SELECT team_id FROM Team WHERE team_id = ?', [teamId]);
        if (teamExists.length === 0) {
            await connection.rollback();
            return { statusCode: 400, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ message: 'Team not found.' }) };
        }
        const [stageExists] = await connection.execute('SELECT stage_id FROM Judging_Stage WHERE stage_id = ?', [stageId]);
        if (stageExists.length === 0) {
            await connection.rollback();
            return { statusCode: 400, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ message: 'Judging stage not found.' }) };
        }

        const assignmentId = uuidv4();
        await connection.execute(
            'INSERT INTO Judge_Assignment (assignment_id, judge_id, team_id, stage_id) VALUES (?, ?, ?, ?)',
            [assignmentId, judgeId, teamId, stageId]
        );

        await connection.commit();

        return {
            statusCode: 201,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Assignment created successfully', assignmentId: assignmentId }),
        };
    } catch (error) {
        if (connection) { await connection.rollback(); }
        console.error('Error creating assignment:', error);
        
        if (error.code === 'ER_DUP_ENTRY') {
            return {
                statusCode: 409,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                body: JSON.stringify({ message: 'Assignment already exists for this judge, team, and stage combination.' }),
            };
        }

        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ message: 'Failed to create assignment', error: error.message }),
        };
    } finally {
        if (connection) {
            // FIX: Release the connection back to the pool
            connection.release();
        }
    }
};